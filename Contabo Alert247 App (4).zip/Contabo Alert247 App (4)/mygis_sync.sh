#!/bin/bash
#RUN THIS only inside dev mygis.gr
#first parameter should be the site path to copy to, eg /var/www/vhosts/mygis.gr/pallini.mygis.gr/

#Options used
#-r recursive
#-R relative
#-v verbose
#-a archive (preserve ownership,timestamps etc) 
#--delete
RED='\033[0;31m'
NC='\033[0m' # No Color

if [[ $# -eq 0 ]] ; then
    echo -e "${RED}You have to specify the directory to sync to. Note the trailing slash. Use absolute path, eg. /var/www/vhosts/mygis.gr/pallini.mygis.gr/${NC}"
    exit 1
fi

rsync --delete -rRva templates/joomgis $1 
rsync --delete -rRva templates/frontend $1
rsync -rRva media/com_joomgis $1
rsync -rRva images $1
rsync --delete -rRva components/com_joomgis $1
rsync --delete -rRva administrator/components/com_joomgis $1
rsync --delete -rRva administrator/language $1
rsync --delete -rRva language $1
