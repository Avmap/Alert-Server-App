<?php
	class Joomgis {

		public static function getLayerConfig($layerID=-1) {

			// Get a reference to the global database object.
			$dbo = JFactory::getDbo();
			$query = $dbo->getQuery(true);
			$query->select('fieldname')
				->from('#__joomgis_field_metadata')
				->where('(published = 1 or fieldname=\'id\') AND fieldType<>12 and fieldType<>15 AND layer_id = '.(int)$layerID);
			$dbo->setQuery($query);
			$fields = $dbo->loadColumn();
			$query = $dbo->getQuery(true);
			$query->select('data_table,host,port')
				->from('#__joomgis_layers')
				->where('id = '.(int)$layerID);
			$dbo->setQuery($query);
			$config=$dbo->loadAssoc();
			return (object)array(
				'data_table'=>$config['data_table'],
				'host'=>$config['host'],
				'port'=>((int)$config['port'])+1,
				'fields'=>$fields
			);
			
		}
		public static function getTile($z,$x,$y,$bounds,$layerConfig){
			$url = 'http://'.$layerConfig->host.':'.$layerConfig->port.'/services/postgis/'.($layerConfig->data_table).
			'/wkb_geometry/vector-tiles/'.(int)$z.'/'.(int)$x.'/'.(int)$y.'.pbf?fields='.urlencode(implode('|||',$layerConfig->fields)).(!empty($bounds)?'&bounds='.$bounds:'');
			
			
			if ($debug){
				echo $url;
				//print_r($layerConfig->fields);
			}else{
				//echo $url;
				
				$ch = curl_init( $url );
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,1); 
				curl_setopt($ch, CURLOPT_TIMEOUT, 3); //timeout in seconds
				curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
				curl_setopt( $ch, CURLOPT_HEADER, true );
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
				list( $header, $contents ) = preg_split( '/([\r\n][\r\n])\\1/', curl_exec( $ch ), 2 );
				//$contents =  curl_exec( $ch );
				//$status = curl_getinfo( $ch );
				//if(curl_error($ch)){
					//echo 'error:' . curl_error($ch);
				//}
				curl_close( $ch );
				
				/*
				$header_text = preg_split( '/[\r\n]+/', $header );
				
				// Propagate headers to response.
				foreach ( $header_text as $header ) {
					if ( preg_match( '/^(?:Content-Type|Content-Language|Set-Cookie):/i', $header ) ) {
						header( $header );
					}
				}
				*/
				print $contents;
			}
		}
	}
	
	//error_reporting(E_ALL);
	ini_set('display_errors', '0');
	define('_JEXEC', 1);
	define('JPATH_BASE', dirname(__FILE__));

	// Load system defines
	if (file_exists(JPATH_BASE . '/defines.php'))
	{
		require_once JPATH_BASE . '/defines.php';
	}

	if (!defined('_JDEFINES'))
	{
		require_once JPATH_BASE . '/includes/defines.php';
	}

	// Get the framework.
	require_once JPATH_LIBRARIES . '/import.legacy.php';
	require_once JPATH_LIBRARIES . '/cms.php';
	
	
	$cache = JFactory::getCache();
	
	$clearCache = isset($_GET['clearCache']) ? $_GET['clearCache']:''; 
	
	if ($clearCache=="1"){
		$cache->cleanCache();
	}
	$cache->setCaching(1);
	$layerID= (int)$_GET['layerID'];
	if (!$layerID){
		$layerID=-1;
	}
	$debug = isset($_GET['debug']) ? $_GET['debug']:''; 
	if ($debug){
		$layerConfig = Joomgis::getLayerConfig($layerID);
	}else{
		$layerConfig = $cache->call( array( 'Joomgis', 'getLayerConfig' ), $layerID );
	}
	//$cache->setCaching(0);
	
	$z = $_GET['z'];
	$x = $_GET['x'];
	$y = $_GET['y'];
	$bounds = $_GET['bounds'];
	//$cache->call( array( 'Joomgis', 'getTile' ), $z,$x,$y,$bounds,$layerConfig );
	Joomgis::getTile($z,$x,$y,$bounds,$layerConfig);
	
?>