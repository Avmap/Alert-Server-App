importScripts("workbox-sw.js");
workbox.setConfig({ debug: false });
workbox.skipWaiting();
workbox.clientsClaim();

const apiCallHandler = new workbox.strategies.NetworkFirst({
  cacheName: 'app'
});
const tileserverCallHandler = new workbox.strategies.NetworkFirst({
  cacheName: 'tileserver'
});
const staticCaches = new workbox.strategies.NetworkFirst({
	cacheName: 'statics'
});

workbox.routing.registerRoute(
  new RegExp('/app.*'),
  apiCallHandler
);
workbox.routing.registerRoute(
  new RegExp('/tileserver[0-9]{0,2}.php.*'),
  tileserverCallHandler
);
workbox.routing.registerRoute(
  new RegExp('/map.*'),
  staticCaches
);

workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute([
  {
    "url": "index_en.html",
    "revision": "b10d63b9844fc5435baa319f5cb41923"
  },
  {
    "url": "index_mk.html",
    "revision": "724ad7136b91442a391b4ea032cc9fe1"
  },
  {
    "url": "index.html",
    "revision": "3fc97ae85ae05c74ee0e7b4fdd242651"
  },
  {
    "url": "info_en.html",
    "revision": "76963a6af43e4cbac4a8464f14726cf8"
  },
  {
    "url": "info_mk.html",
    "revision": "76963a6af43e4cbac4a8464f14726cf8"
  },
  {
    "url": "info.html",
    "revision": "76963a6af43e4cbac4a8464f14726cf8"
  },
  {
    "url": "map_en.html",
    "revision": "bba4d637e29644c91c1c4567c56121d3"
  },
  {
    "url": "map_mk.html",
    "revision": "4f4b2b006e2d9fb7400f3c72b9fcb0ba"
  },
  {
    "url": "map.html",
    "revision": "dad1e9bee8285cddfcf2d5d4112a5396"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/charts.tpl.html",
    "revision": "b5e58c7a4d3da37d7b5e8d686aa4d1f3"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/drilldown.tpl.html",
    "revision": "830b5a3dcc0d2adc1b478a0f7c6fe036"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/excelRow.tpl.html",
    "revision": "ff9bbb6914b7e5a570d7b4466c075258"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/info_iframe.tpl.html",
    "revision": "c093cb472a4ad1ea72cca27c0dddccbe"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/info.tpl_backup.html",
    "revision": "dca0d8a18d3fdb469c7339f07fa8ce36"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/info.tpl.html",
    "revision": "33da7ae1cc61deb824550253e290e865"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificateCreation.tpl.html",
    "revision": "e7ecdb2b0fa10ecb82d95a2509d396d3"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificateManagement.tpl.html",
    "revision": "e18fba63c62c8dbee4ff52d4ec8799c6"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificatePrintManagement.tpl.html",
    "revision": "86e57e29cb89f9ca5e580f94c9159502"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificatePrintManagementPopup.tpl.html",
    "revision": "19194ed4eafeaffa0a3b6479bc3b3988"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificates.tpl.html",
    "revision": "b526c8c724fec8a753ba156d04165eaa"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/certificatesUserInput.tpl.html",
    "revision": "1b7f30d847a1f01271c6b8d09b905ec8"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/joinedResults.tpl.html",
    "revision": "2b4750e03b77aecd04f98a8be1e3e699"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/nodes.tpl.html",
    "revision": "5d5fd85a751487b13f7265298e3d8e75"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/infoSub/userJoinedResults.tpl.html",
    "revision": "d213e2a2c602b48b06c43bf2b68bc3bd"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/layerControl.tpl.html",
    "revision": "c5b792c7236ffb6312723f938895f6f2"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/loadMaps.tpl.html",
    "revision": "8e3bfb8c0dc742af2facfbeffa219573"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/mapPrint.tpl.html",
    "revision": "aee7017eec0b5a3bed299ab204e28c14"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/mapPrintLegend.tpl.html",
    "revision": "e06ea55a76d703774ac3fafba6ae0954"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/mapPrintOptions.tpl.html",
    "revision": "eecd419ce190a360f2d9fdb4a2b8a5c5"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/searchEntry.tpl.html",
    "revision": "37d2ac546c409cf219f5bd30a444e2c9"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/searchEntry2.tpl.html",
    "revision": "8ee995a85ae58071cbf8b4bb2fbfe16b"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/searchPanel.tpl.html",
    "revision": "193976658ce1d71753f26afddb648083"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/table.tpl.html",
    "revision": "2e4d3e7fab72e7886b359000437d4061"
  },
  {
    "url": "media/com_joomgis/assets/js/controls/tmpl/tooltip.tpl.html",
    "revision": "86177a57bd7af35b12252ff05aef3c54"
  },
  {
    "url": "media/tinymce/templates/01_mygis_map.html",
    "revision": "e243ee215d6a95dff895891a5d3065b5"
  },
  {
    "url": "media/tinymce/templates/02_mygis_layer_field.html",
    "revision": "36734259c39f507316bfd3baec628ab3"
  },
  {
    "url": "media/tinymce/templates/02a_mygis_joined.html",
    "revision": "89b4222695cafe984dc4d97bc33eb1f7"
  },
  {
    "url": "media/tinymce/templates/02b_mygis_userjoined.html",
    "revision": "d433dcf81854f05c4c30fbb6040a87f5"
  },
  {
    "url": "media/tinymce/templates/02c_mygis_nodes.html",
    "revision": "23ed072380b2f857510b90461e7713f3"
  },
  {
    "url": "media/tinymce/templates/02d_mygis_nodeswgs.html",
    "revision": "62742ab28779dff186934506c44b6f69"
  },
  {
    "url": "media/tinymce/templates/02e_mygis_pictures.html",
    "revision": "308c20b1b3a6e07ccccd72212a8bf7f6"
  },
  {
    "url": "media/tinymce/templates/03_mygis_area.html",
    "revision": "cdc02f39e57722f949c59a476095a9cb"
  },
  {
    "url": "media/tinymce/templates/04_mygis_centroid.html",
    "revision": "d23ddee4af0e0a74d56362ff5e3573ec"
  },
  {
    "url": "media/tinymce/templates/05_mygis_length.html",
    "revision": "aceaca5f37ac8e8fd3a03ed46258f2fc"
  },
  {
    "url": "media/tinymce/templates/06_mygis_perimeter.html",
    "revision": "c9fdf4d3171abb4214b73bc6fd206564"
  },
  {
    "url": "media/tinymce/templates/07_mygis_currentdate.html",
    "revision": "d944806f113ecafeabe4e6fb6e534e40"
  },
  {
    "url": "media/tinymce/templates/08_mygis_currenttime.html",
    "revision": "ebc8351297b3bd67bfa6e72489a32819"
  },
  {
    "url": "app.bundle.js",
    "revision": "7f95b2cb978c28da552d24247e167c88"
  },
  {
    "url": "common.bundle.js",
    "revision": "febb90e5187679ad418fd63303af6f9b"
  },
  {
    "url": "highcharts.bundle.js",
    "revision": "ee965f04a2dd0b389536d0ad757b6984"
  },
  {
    "url": "info.bundle.js",
    "revision": "9253862bfbe58d0464e25c08a94f2eb4"
  },
  {
    "url": "joomCSS.bundle.js",
    "revision": "9c06e552445303db300210cd683c6aa3"
  },
  {
    "url": "joomgis.bundle.js",
    "revision": "30bdc32f3c0b9182013eca4e7b7f86b0"
  },
  {
    "url": "jquery.bundle.js",
    "revision": "a85484b19c84edbd84ab29394c6dd429"
  },
  {
    "url": "jqWidgets.bundle.js",
    "revision": "da2e6b8a9e0bb8f04bcb66931ee23721"
  },
  {
    "url": "jsv.bundle.js",
    "revision": "c3949e064396607b9795972081a7197b"
  },
  {
    "url": "leaflet.bundle.js",
    "revision": "441e1c0a87c58804944262bd8c592ab8"
  },
  {
    "url": "libCSS.bundle.js",
    "revision": "98283c4b5ba14e7233a592bf502caf31"
  },
  {
    "url": "maps.bundle.js",
    "revision": "9b6ce253a7fe9695d266aab2d142f26b"
  },
  {
    "url": "media/tinymce/jquery.tinymce.min.js",
    "revision": "72d2383f04d5ad2b54e8286227493b80"
  },
  {
    "url": "media/tinymce/langs/af.js",
    "revision": "7e32489fd3ac059f74bb70d7306c8c1d"
  },
  {
    "url": "media/tinymce/langs/ar.js",
    "revision": "a0c379ca3f6d06df72738f46f05f9885"
  },
  {
    "url": "media/tinymce/langs/be.js",
    "revision": "8b7e5db53f210233b15ef1595f146e99"
  },
  {
    "url": "media/tinymce/langs/bg.js",
    "revision": "2c930398b9e1a378839f81ac10685a63"
  },
  {
    "url": "media/tinymce/langs/bs.js",
    "revision": "e017f04e6fcc882e37ed166d43ecaa7a"
  },
  {
    "url": "media/tinymce/langs/ca.js",
    "revision": "62fbd6d654a1785f2874fbb82292c405"
  },
  {
    "url": "media/tinymce/langs/cs.js",
    "revision": "ba3a3cbcf5e2edff61df82835f842990"
  },
  {
    "url": "media/tinymce/langs/cy.js",
    "revision": "5470471e6d7c7d96309d80cb4acd13f8"
  },
  {
    "url": "media/tinymce/langs/da.js",
    "revision": "e60d1e27d974bbd6cbd892c8620a0be2"
  },
  {
    "url": "media/tinymce/langs/de.js",
    "revision": "cb20c75d15fc8eb3461f7ae533e8e679"
  },
  {
    "url": "media/tinymce/langs/el.js",
    "revision": "26e27416e08cda1927201e3173a0a9ff"
  },
  {
    "url": "media/tinymce/langs/es.js",
    "revision": "ef5ccba778d10c87c539b76ead3c5b58"
  },
  {
    "url": "media/tinymce/langs/et.js",
    "revision": "f0ac017f163f69abdb714eddc5e2830e"
  },
  {
    "url": "media/tinymce/langs/eu.js",
    "revision": "b65dbfd663318fef985d7e4b7f542633"
  },
  {
    "url": "media/tinymce/langs/fa.js",
    "revision": "2b2d3376f6ff03eace59784b96a46290"
  },
  {
    "url": "media/tinymce/langs/fi.js",
    "revision": "0c2df3c349054f8aa5ab780000953808"
  },
  {
    "url": "media/tinymce/langs/fo.js",
    "revision": "3e0e4671f0a6b4a837c8cc2297be349e"
  },
  {
    "url": "media/tinymce/langs/fr.js",
    "revision": "0b338e984e6a35621413988c0cabe59f"
  },
  {
    "url": "media/tinymce/langs/ga.js",
    "revision": "44e27a1e07a8a0189da58537a7a76cf9"
  },
  {
    "url": "media/tinymce/langs/gl.js",
    "revision": "5e27dfdc68947eb0ec9bf0a8455fe5cd"
  },
  {
    "url": "media/tinymce/langs/he.js",
    "revision": "37b81ea8854bbddf4ceecd1f3a26a56b"
  },
  {
    "url": "media/tinymce/langs/hr.js",
    "revision": "1999f5abedb0516317e164429b3e2d2b"
  },
  {
    "url": "media/tinymce/langs/hu.js",
    "revision": "297cd889725f4f597c27bcccf5a01556"
  },
  {
    "url": "media/tinymce/langs/id.js",
    "revision": "389e781663a9a758d5c686c94ebe658c"
  },
  {
    "url": "media/tinymce/langs/it.js",
    "revision": "1182d5e000df56a3f1ed35eea137b29c"
  },
  {
    "url": "media/tinymce/langs/ja.js",
    "revision": "43ff4b17e9d39a5a53b70424530c1e91"
  },
  {
    "url": "media/tinymce/langs/ka.js",
    "revision": "55e8d9602b2552f03a8ec232beb01c0a"
  },
  {
    "url": "media/tinymce/langs/km.js",
    "revision": "20ed1465a07996ea9a8d4ebb50abef4f"
  },
  {
    "url": "media/tinymce/langs/ko.js",
    "revision": "5ad4411a1ac7748b454d353a76f4900e"
  },
  {
    "url": "media/tinymce/langs/lb.js",
    "revision": "3882f455e0f3c3b7e69951cddc029693"
  },
  {
    "url": "media/tinymce/langs/lt.js",
    "revision": "d1ac13e807c163a1a415b3b2b58234d3"
  },
  {
    "url": "media/tinymce/langs/lv.js",
    "revision": "4a977dac8ed19196452debe0d3383ee9"
  },
  {
    "url": "media/tinymce/langs/mk.js",
    "revision": "2067cd7ed2792c03cc7eb065bc28841d"
  },
  {
    "url": "media/tinymce/langs/ms.js",
    "revision": "eb8e587aac19ec5c5432ed657b29db5e"
  },
  {
    "url": "media/tinymce/langs/nb.js",
    "revision": "798259b2afb68ce488149041d0ef87ea"
  },
  {
    "url": "media/tinymce/langs/nl.js",
    "revision": "ac609d9c2ae4abf7b89db7b54e0c0c59"
  },
  {
    "url": "media/tinymce/langs/pl.js",
    "revision": "55b52264ba6af1d2b72389b295775398"
  },
  {
    "url": "media/tinymce/langs/pt-BR.js",
    "revision": "175e7cc641054a012dea13ff6da412a2"
  },
  {
    "url": "media/tinymce/langs/pt-PT.js",
    "revision": "95775918ad378d70041a6c17ba348efb"
  },
  {
    "url": "media/tinymce/langs/ro.js",
    "revision": "94c8cba9a4df2eab851abbc0dcf87a14"
  },
  {
    "url": "media/tinymce/langs/ru.js",
    "revision": "697267c1596165b08941a6611987d61c"
  },
  {
    "url": "media/tinymce/langs/si-LK.js",
    "revision": "37b924afdaa8cc071a79c28a97f16c96"
  },
  {
    "url": "media/tinymce/langs/sk.js",
    "revision": "bab974dac90d32e890ea22e7018cde38"
  },
  {
    "url": "media/tinymce/langs/sl.js",
    "revision": "9d0a8ce932b7073f9fc3cabdd0d86e43"
  },
  {
    "url": "media/tinymce/langs/sr.js",
    "revision": "ce0b00505e20ce27858859ae6cd28406"
  },
  {
    "url": "media/tinymce/langs/sv.js",
    "revision": "cb53c6c69c3395a581ff1e07316a03f9"
  },
  {
    "url": "media/tinymce/langs/sy.js",
    "revision": "b32b2f1724af6fcbc093e7a7e73b04d3"
  },
  {
    "url": "media/tinymce/langs/ta.js",
    "revision": "3fde13492a74b85f12bb3e6c4be26f1d"
  },
  {
    "url": "media/tinymce/langs/th.js",
    "revision": "58c39edc7cff5dbfedf20a6b1deee44f"
  },
  {
    "url": "media/tinymce/langs/tr.js",
    "revision": "fb44a11bea7df2f10b75414312e5c34f"
  },
  {
    "url": "media/tinymce/langs/ug.js",
    "revision": "0108df06dde4b58814709af674bfa67d"
  },
  {
    "url": "media/tinymce/langs/uk.js",
    "revision": "9666e47e2b4f1cdd5d8dcb574d62798b"
  },
  {
    "url": "media/tinymce/langs/vi.js",
    "revision": "0adf95ec2172f4ab2c65ff7d83e85857"
  },
  {
    "url": "media/tinymce/langs/zh-CN.js",
    "revision": "49620b067e588001e2b00ce31dd7fd8e"
  },
  {
    "url": "media/tinymce/langs/zh-TW.js",
    "revision": "e7d042f298b0bcb15c845fed1f3d686a"
  },
  {
    "url": "media/tinymce/plugins/advlist/plugin.min.js",
    "revision": "285b3471b767010b1997285868f9f52d"
  },
  {
    "url": "media/tinymce/plugins/anchor/plugin.min.js",
    "revision": "90e4a48f17e58d4edb414a02614e916b"
  },
  {
    "url": "media/tinymce/plugins/autolink/plugin.min.js",
    "revision": "d34dabb4475cc9a5ce410514f6ea52ef"
  },
  {
    "url": "media/tinymce/plugins/autoresize/plugin.min.js",
    "revision": "cc640497498f60c45a76d2e9bb1972ff"
  },
  {
    "url": "media/tinymce/plugins/autosave/plugin.min.js",
    "revision": "3292b90390aa3a4c6aede0043b4a4864"
  },
  {
    "url": "media/tinymce/plugins/bbcode/plugin.min.js",
    "revision": "1a0392017315d7ebbdf2e1576917105e"
  },
  {
    "url": "media/tinymce/plugins/charmap/plugin.min.js",
    "revision": "67dfba90518164c702afd122a32e678f"
  },
  {
    "url": "media/tinymce/plugins/code/plugin.min.js",
    "revision": "94306385380ed507291ea639c060a975"
  },
  {
    "url": "media/tinymce/plugins/codesample/plugin.min.js",
    "revision": "2a4899acb9de583b4ae5950551eb02e2"
  },
  {
    "url": "media/tinymce/plugins/colorpicker/plugin.min.js",
    "revision": "032a5e2f535db44c61e63eb4e2029676"
  },
  {
    "url": "media/tinymce/plugins/contextmenu/plugin.min.js",
    "revision": "7dae3fd90ffa7a1e9eebdff9cfa38f98"
  },
  {
    "url": "media/tinymce/plugins/directionality/plugin.min.js",
    "revision": "8f1231b98766f32a67bc70b93fba6c78"
  },
  {
    "url": "media/tinymce/plugins/emoticons/plugin.min.js",
    "revision": "3bf5369b3c0395c9377af76e3b696678"
  },
  {
    "url": "media/tinymce/plugins/fullpage/plugin.min.js",
    "revision": "df43e0b0ec686d7e36f777203c833170"
  },
  {
    "url": "media/tinymce/plugins/fullscreen/plugin.min.js",
    "revision": "ae2948cb5502115e2f16efd7118fab84"
  },
  {
    "url": "media/tinymce/plugins/help/plugin.min.js",
    "revision": "2b6ee66accba1afb0f75ca2afcf5cc68"
  },
  {
    "url": "media/tinymce/plugins/hr/plugin.min.js",
    "revision": "0911253e82299afa85c2950c033bb68f"
  },
  {
    "url": "media/tinymce/plugins/image/plugin.min.js",
    "revision": "11b40b31ddb486f9e30c9d1ed4552e3f"
  },
  {
    "url": "media/tinymce/plugins/imagetools/plugin.min.js",
    "revision": "d6c064ffedb9d8ef4d5aa8b016dd11cf"
  },
  {
    "url": "media/tinymce/plugins/importcss/plugin.min.js",
    "revision": "81ab42b4298abec27ab7344a935496f4"
  },
  {
    "url": "media/tinymce/plugins/insertdatetime/plugin.min.js",
    "revision": "b6689082728528fecf3bb24dad0ab243"
  },
  {
    "url": "media/tinymce/plugins/legacyoutput/plugin.min.js",
    "revision": "ce6033d0ec61d6bf679478563280b661"
  },
  {
    "url": "media/tinymce/plugins/link/plugin.min.js",
    "revision": "3a41ab01a5cad2634060aa907bb62ca3"
  },
  {
    "url": "media/tinymce/plugins/lists/plugin.min.js",
    "revision": "682f57141196483af3d9f2c915a48001"
  },
  {
    "url": "media/tinymce/plugins/media/plugin.min.js",
    "revision": "d7e220a1e0d08db2c9ac95f88acd9c36"
  },
  {
    "url": "media/tinymce/plugins/nonbreaking/plugin.min.js",
    "revision": "094747a127e58e23f3d1810658b4948a"
  },
  {
    "url": "media/tinymce/plugins/noneditable/plugin.min.js",
    "revision": "42095ecde1e68a1c8d26fd02a551ef14"
  },
  {
    "url": "media/tinymce/plugins/pagebreak/plugin.min.js",
    "revision": "f36d4ba8dd9c1bf19c99d32767df34d4"
  },
  {
    "url": "media/tinymce/plugins/paste/plugin.min.js",
    "revision": "364c477bb8bc7b8a40c4d032505dc67a"
  },
  {
    "url": "media/tinymce/plugins/preview/plugin.min.js",
    "revision": "25162b1baf07a9a1124c87030b14173a"
  },
  {
    "url": "media/tinymce/plugins/print/plugin.min.js",
    "revision": "3ce46fc74efb2b05e845a14463db3894"
  },
  {
    "url": "media/tinymce/plugins/save/plugin.min.js",
    "revision": "dd8019a71ce3edc8516c41326839f180"
  },
  {
    "url": "media/tinymce/plugins/searchreplace/plugin.min.js",
    "revision": "b1c1ffe6ccaab11058c271a091cd6e4c"
  },
  {
    "url": "media/tinymce/plugins/spellchecker/plugin.min.js",
    "revision": "b99269a9d9c444a2b570f87ec3a02445"
  },
  {
    "url": "media/tinymce/plugins/tabfocus/plugin.min.js",
    "revision": "587abe9f7faa2cbc010f896682034935"
  },
  {
    "url": "media/tinymce/plugins/table/plugin.min.js",
    "revision": "a655a8feff798b2cd5b55478d867dd76"
  },
  {
    "url": "media/tinymce/plugins/template/plugin.min.js",
    "revision": "57d4a07f779ef11b0b255b2d3c259c6f"
  },
  {
    "url": "media/tinymce/plugins/textcolor/plugin.min.js",
    "revision": "4972c9189178e32ab4a9fb79e05affdf"
  },
  {
    "url": "media/tinymce/plugins/textpattern/plugin.min.js",
    "revision": "47f2b94b4eedd537a7a6eea5ff1a7731"
  },
  {
    "url": "media/tinymce/plugins/toc/plugin.min.js",
    "revision": "f6d8a1859b73c52a00695b0f279b69ce"
  },
  {
    "url": "media/tinymce/plugins/visualblocks/plugin.min.js",
    "revision": "1216d8978457982aa4a80261251d3857"
  },
  {
    "url": "media/tinymce/plugins/visualchars/plugin.min.js",
    "revision": "5ba60842f3d87fd09c55139436375b13"
  },
  {
    "url": "media/tinymce/plugins/wordcount/plugin.min.js",
    "revision": "a808994746f2b3620a05140988efe42d"
  },
  {
    "url": "media/tinymce/templates/jquery.min.js",
    "revision": "5506e81cd13183312c8cf5425c9f8c5e"
  },
  {
    "url": "media/tinymce/themes/inlite/theme.min.js",
    "revision": "8d5714bcfcecb975dd30af36676679f0"
  },
  {
    "url": "media/tinymce/themes/mobile/theme.min.js",
    "revision": "628f99cc8e3d1bb37cd5048508dceef5"
  },
  {
    "url": "media/tinymce/themes/modern/theme.min.js",
    "revision": "07ca7415b1629fd0dafae992ba9b1779"
  },
  {
    "url": "media/tinymce/tinymce.min.js",
    "revision": "761270f20e6877865971e1f75a460255"
  },
  {
    "url": "pdfmake.bundle.js",
    "revision": "a752dfa0809be01f6f4acdd0cf3d746e"
  },
  {
    "url": "tinyMCE.bundle.js",
    "revision": "c6b588c4f304990057d7bef1d3bdf226"
  },
  {
    "url": "workbox-sw.js",
    "revision": "ab9c282305eb780b9cbc17e05b6053ad"
  }
]);