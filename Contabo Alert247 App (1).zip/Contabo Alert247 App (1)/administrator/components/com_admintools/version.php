<?php
/**
 * @package   admintools
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('ADMINTOOLS_VERSION', '5.3.2');
define('ADMINTOOLS_DATE', '2019-05-28');
define('ADMINTOOLS_PRO','1');