<?php
/**
 * @package   admintools
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

/** @var $this  Akeeba\AdminTools\Admin\View\NginXConfMaker\Html */

defined('_JEXEC') or die;

?>
<pre><?php echo $this->escape($this->nginxconf);?></pre>
