<?php defined('_JEXEC') or die;
require_once __DIR__ . '/helper.php';
//$data = ModAvAreaMapHelper::getItems();

if (true){
	require JModuleHelper::getLayoutPath('mod_av_gismap');
}else{
	require JModuleHelper::getLayoutPath('mod_av_gismap','normal');
}