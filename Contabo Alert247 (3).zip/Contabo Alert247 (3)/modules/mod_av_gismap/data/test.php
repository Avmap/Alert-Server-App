<?php

const _JEXEC = 1;
if (!defined('_JDEFINES'))
{
	define('JPATH_BASE', $_SERVER['DOCUMENT_ROOT']);
	require_once JPATH_BASE . 'includes/defines.php';
}
// Get the framework.
require_once JPATH_LIBRARIES . '/import.legacy.php';

// Bootstrap the CMS libraries.
require_once JPATH_LIBRARIES . '/cms.php';

/**
 * Title:   MySQL to GeoJSON (Requires https://github.com/phayes/geoPHP)
 * Notes:   Query a MySQL table or view and return the results in GeoJSON format, suitable for use in OpenLayers, Leaflet, etc.
 * Author:  Bryan R. McBride, GISP
 * Contact: bryanmcbride.com
 * GitHub:  https://github.com/bmcbride/PHP-Database-GeoJSON
 */

# Include required geoPHP library and define wkb_to_json function
include_once(JPATH_LIBRARIES.'/geophp/geoPHP.inc');
function wkb_to_json($wkb) {
    $geom = geoPHP::load($wkb,'wkb');
    return $geom->out('json');
}

$db = JFactory::getDbo();
$sql = 'SELECT *,
			AsWKB(SHAPE) as wkb
		FROM erga_polygons';
$db->setQuery($sql);
$results = $db->loadAssocList();

# Build GeoJSON feature collection array
$geojson = array(
   'type'      => 'FeatureCollection',
   'features'  => array()
);

foreach ($results as $row){
	$properties = $row;
    # Remove wkb and geometry fields from properties
    unset($properties['wkb']);
    unset($properties['SHAPE']);
    $feature = array(
         'type' => 'Feature',
		 
		 'crs' => array(
			'type' => 'name',
			'properties' => array(
				'name' => 'urn:ogc:def:crs:EPSG::4326'	//this must be detected somehow
			)
		 ),
         'geometry' => json_decode(wkb_to_json($row['wkb'])),
         'properties' => $properties,
		 
    );
    # Add feature arrays to feature collection array
    array_push($geojson['features'], $feature);
}

header('Content-type: application/json');

echo json_encode($geojson, JSON_NUMERIC_CHECK);
?>