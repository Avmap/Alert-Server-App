<?php 
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$modulePath= "/modules/mod_av_gismap/";

$document->addStyleSheet("https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/leaflet.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-locatecontrol/v0.43.0/L.Control.Locate.css");
$document->addStyleSheet($modulePath."assets/leaflet-groupedlayercontrol/leaflet.groupedlayercontrol.css");
$document->addStyleSheet($modulePath."assets/css/app.css");
?>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	<div class="container-fluid">
	
	</div>
</div>