<?php 
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$modulePath= "/modules/mod_av_gismap/";

//$document->addStyleSheet("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css");
//$document->addStyleSheet("https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css");
$document->addStyleSheet("https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/leaflet.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css");
$document->addStyleSheet("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-locatecontrol/v0.43.0/L.Control.Locate.css");
$document->addStyleSheet($modulePath."assets/leaflet-groupedlayercontrol/leaflet.groupedlayercontrol.css");
$document->addStyleSheet($modulePath."assets/css/app.css");

?>
<div id="map"></div>


<?php
	$document->addScript("https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.10.5/typeahead.bundle.min.js");
	$document->addScript("https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.3/handlebars.min.js");
	$document->addScript("https://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js");
	$document->addScript("https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.0.3/leaflet-src.js");
	$document->addScript("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/leaflet.markercluster.js");
	$document->addScript("https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-locatecontrol/v0.43.0/L.Control.Locate.min.js");
	$document->addScript("https://cdnjs.cloudflare.com/ajax/libs/proj4js/2.4.3/proj4.js");

	
?>

<script src="<?=$modulePath?>assets/proj4leaf/proj4leaflet.js"></script>
<script src="<?=$modulePath?>assets/leaflet-groupedlayercontrol/leaflet.groupedlayercontrol.js"></script>
<script src="<?=$modulePath?>assets/js/app.js"></script>