<?php
/**
* @package EverLive.net Plugin for Joomla 2.x and 3.x
* @version $Id: installer.php 101 2015-03-05 $
* @author EverLive.net
* @copyright (C) 2015 EverLive.net. All rights reserved.
* @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// No direct access to this file
defined('_JEXEC') or die;

class plgsystemEvadminbarInstallerScript
{		
	public function preflight($type, $parent) {
		
	}
	
	public function postflight($type, $parent) 
	{	
		if ( $type == 'install' ) 
		{       
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$fields = array(
				$db->quoteName('enabled') . ' = ' . (int) 1,
				$db->quoteName('ordering') . ' = ' . (int) 9999
			);

			$conditions = array(
				$db->quoteName('element') . ' = ' . $db->quote('evadminbar'), 
				$db->quoteName('type') . ' = ' . $db->quote('plugin')
			);

			$query->update($db->quoteName('#__extensions'))->set($fields)->where($conditions);

			$db->setQuery($query);   
			$db->execute();     
		}
		
		$this->showInstall();
		
		return true;
	}
	
	public function install($parent) {}
	
	public function update($parent) {}
	
	public function uninstall($parent) {}

	protected function showInstall() {
		$lang = JFactory::getLanguage(); 
		$lang->load('plg_system_evadminbar', JPATH_ADMINISTRATOR); 
	
?>
<style type="text/css">
#ev-installer-left {
	float: left;
	padding: 10px;
	width:30%;	
}

#ev-installer-right {
	float: left;
	padding: 10px;
	width:60%;
}

</style>

<div id="ev-installer-left">
	<a target="_blank" href="http://www.everlive.net/getting-started-cloud-backup.html">
		<img src="<?php echo JURI::root(); ?>plugins/system/evadminbar/images/everlive2_300.png" alt="<?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV'); ?>" />
	</a>
	<h2><a target="_blank" href="http://www.EverLive.net/joomla-extensions.html"><?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV_ALL'); ?></a></h2>
</div>
<div id="ev-installer-right">
<h3><?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV_HOWTO_HEAD') ?></h3>
<p><?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV_HOWTO_INFO') ?></p>
<a target="_blank" href="<?php echo JURI::root(); ?>" class="btn btn-primary btn-large"><?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV_HOWTO_CHECK') ?></a>
<a target="_blank" href="http://www.everlive.net/joomla-extensions/15-joomla-admin-from-frontend.html" class="btn btn-primary btn-large"><?php echo JText::_('PLG_SYS_EVADMINBAR_POSTINSTALL_JEEV_UGCAP') ?></a>
</div><br/><br/>
<?php	
	}
}
?>
