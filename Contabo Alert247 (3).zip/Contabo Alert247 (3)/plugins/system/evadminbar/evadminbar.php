<?php
/**
* @package EverLive.net Plugin for Joomla 2.x and 3.x
* @version $Id: evadminbar.php 103 2015-03-05 $
* @author EverLive.net
* @copyright (C) 2015 EverLive.net. All rights reserved.
* @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
define('EV_ADMINBAR_MOD_SEP','MODSEP');	
define('EV_ADMINBAR_MENU_SEP','MENUSEP');
define('EV_ADMINBAR_MENU_IS_FIRST','#@#');
define('EV_ADMINBAR_ARTICLE_SEP','ARTICLESEP');
define('EV_ADMINBAR_THIS_PLUGIN_PATH',JPATH_PLUGINS.'/system/evadminbar/');	

jimport( 'joomla.plugin.plugin' );

class plgSystemEvadminbar extends JPlugin
{
	var $_cm_isAdmin;
	var $_allowAdminOps = false;
	var $_pluginUrlPath;
	var $_isPro=false;
	var $_proHelper=null;
	
	function plgSystemEvadminbar(& $subject, $config) {
		parent::__construct($subject, $config);
		$this->loadLanguage();		
	}

	function _isAdmin(){
		$app = JFactory::getApplication();
		$b = $app->isAdmin();
		
		$this->_cm_isAdmin = $b;
		return $b;
	}

	private function _initVars(){
		$this->_pluginUrlPath = JURI::root().'plugins/system/evadminbar/';
		$ovFile = JPATH_PLUGINS.'/system/evadminbar/helper_pro.php';
		
		if ( !$this->_cm_isAdmin ) $this->_allowAdminOps();		
		
		if (file_exists($ovFile)){
			include_once($ovFile);
			$this->_isPro=true;
			$this->_proHelper = new helper_proEvadminbar($this);
		}
	}
	
	function onAfterInitialise(){
		$this->_isAdmin();
		$this->_initVars();
		
		if ( $this->_cm_isAdmin ){
			$this->_serveAdminRequest();
		}else{
			if ($this->_allowAdminOps){		
				if ($this->_isPro){
					$this->_proHelper->customOverrides();
				}
			}
		}
	}

	function onAfterRoute(){
		if ( $this->_cm_isAdmin ){
		}else{
			
		}	
	}
	
	function onAfterDispatch(){

	}
	
	function onAfterRender(){
		if ( $this->_cm_isAdmin ){
			
		}else{
			if ($this->_allowAdminOps){		
				$this->_showAdminBar();
				if ($this->_isPro){
					$this->_proHelper->showOperationsImagesMods();
					$this->_proHelper->showOperationsImagesMenus();
					$this->_proHelper->showOperationsImagesArticles();
				}
			}
		}
	}

	function onRenderModule( &$module, &$attribs ){
		if (!$this->_allowAdminOps) return; if (!$this->_isPro) return;
		//$this->_myVarDump($module);
		$this->_proHelper->_modifyModContent($module);
	}

	public function onContentPrepare($context, &$article, &$params, $page = 0){
		if (!$this->_allowAdminOps) return; if (!$this->_isPro) return;
		$this->_proHelper->modifyArticleContent($context, $article, $params, $page);
	}
	
	public function _myVarDump(&$var){
		echo '<pre>';
		var_dump($var);
		echo '</pre>';
		die();
	}
	
	public function afterMenuGetItems( $items, $attributes, $values ){
		if (!$this->_isPro) return;
		if (!$this->_allowAdminOps) return;
		$this->_proHelper->modifyMenuContent( $items, $attributes, $values );
	}
		
	public function _allowAdminOps(){
		$jUser = JFactory::getUser();
		if ($jUser->id <= 0) return;
		
		$b = $jUser->authorise('core.login.admin');	if (!$b) return;
		
		$b = $this->_isKsecureOk();
		$this->_allowAdminOps = $b;
		return $b;
	}
	
	private function _isKsecureOk(){
		//check if ksecure is there.
		$session = JFactory::getSession();
		$ks = $session->get('ksecure',0);
		
		if ($ks==0){	//new session
			$q = "SELECT params FROM `#__extensions` WHERE `type`='plugin' 
						AND `element`='ksecure' AND `enabled`= 1 ";
			$kp = json_decode( $this->getResult($q) );
			if (@$kp->password=='' || @$kp->enabled!=1){	//ksecure not active. its ok.
				$session->set('ksecure', 1);
				return true;
			}else{
				if (!array_key_exists(@$kp->password,$_GET)) {
					return false;
				}
			}
			$session->set('ksecure', 1);
		}else if ($ks==-1){
			return false;
		}
		return true;
	}
	
	private function _showAdminBar(){
		if (!$this->_allowAdminOps) return;

		$url = JURI::root().'administrator/index.php';
		$session = JFactory::getSession();
		$pstr = 'xmjuexnhse=1&fxsesn='.md5($session->getId());
		$url = $url.'?'.$pstr; //die($url);
		$h ='<div id="evadmb-divmain" name="evadmb-divmain" class="evadmb-divmain" onclick="evadmbClose();" >
				<iframe id="evadmb_ifm" delay-src="'.$url.'" style="border:none; position:relative; width:90%;height:90%;" onload="evadbmIfmLoaded();" ></iframe>
			</div>
			';
		
		$content  = JResponse::getBody();
		$p1=stripos($content,'<body'); if ($p1===false) return;
		$p1=stripos($content,'<',$p1+4); if ($p1===false) return;
		$content = substr_replace($content,$h,$p1,0);

		//x $content = str_ireplace('/jquery','',$content);
		
		$cj = $this->_getCss().$this->_getJs();
		//$content = str_ireplace('</body>',$cj.'</body>',$content);
		$content = str_ireplace('</head>',$cj.'</head>',$content);
		
		JResponse::setBody( $content );			
	}
	
	private function _getJs(){
		$corner = $this->params->get('activation_corner', 2);
		
		$session = JFactory::getSession();
		$pstr = 'xmjuexnhse=1&fxsesn='.md5($session->getId());
		$baseUrl = JURI::root().'administrator/index.php?'.$pstr;

		
		$h='<script>window.jQuery || document.write(\'<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js">\x3C/script>\')</script>
			<script type="text/javascript"> 
				var evadmGesturePos = '.$corner.';
				var evadmBaseUrl = "'.$baseUrl.'";
			</script>
			<script type="text/javascript" src="'.$this->_pluginUrlPath.'media/main.js?'.time().'"></script>
			';

		if ($this->_isPro){
			$h.='<script type="text/javascript" src="'.$this->_pluginUrlPath.'media/main_pro.js?'.time().'"></script>';
		}			
		
		return $h;
	}
	
	private function _getCss(){
		$h = '<link rel="stylesheet" href="'.$this->_pluginUrlPath.'media/main.css?'.time().'" type="text/css" />';
		return $h;
	}

	private function _getAdminLoggedIn(){
		$jUser = JFactory::getUser();
		//$b = $jUser->get('isRoot');
		$b = $jUser->authorise('core.login.admin');
		
		$db = JFactory::getDBO();
		$fsess = JRequest::getVar('fxsesn', '', 'request');
		
		if ($jUser->id > 0){
			if (!$b){
				//
			}else{
				return;
			}
		}

		$conf = JFactory::getConfig();
		if (version_compare(JVERSION,'3.0.0','>=')){
			$cfgSessTimeSeconds = $conf->get('lifetime');
		}else{
			$cfgSessTimeSeconds = $conf->getValue('config.lifetime');
		}
		$cfgSessTimeSeconds = $cfgSessTimeSeconds * 60;
		
		$q = "SELECT * FROM #__session WHERE 
					`time` + ".$db->quote($cfgSessTimeSeconds) ." > UNIX_TIMESTAMP()
					AND md5(session_id) = ".$db->quote($fsess);
		$fsess = $this->getRow($q);
		$suid  = $fsess->userid;
		$session = JFactory::getSession();
		
		if($suid<=0){	//destroy back end session if front end user is not logged in.
			$q = "DELETE FROM #__session WHERE session_id = ".$db->quote($session->getId());
			$this->doQuery($q);
			return;
		}
		
		$session->set('user', new JUser($suid));
		$session->set('evadmb_psess_id', $fsess->session_id);
	}
	
	private function _serveAdminRequest(){
		//check if this is a child back end session and logout if parent is logged out from frontend.
		$session = JFactory::getSession();
		$fsess = $session->get('evadmb_psess_id','');
		$db = JFactory::getDBO();
		
		if ($fsess!=''){
			$q = "SELECT * FROM #__session WHERE userid>0 AND session_id = ".$db->quote($fsess);
			$row = $this->getRow($q);
			if (@$row->session_id==''){
				$q = "DELETE FROM #__session WHERE session_id = ".$db->quote($session->getId());
				$this->doQuery($q);
				$session->destroy();
				return;			
			}
		}
		
		$ab	= JRequest::getVar('xmjuexnhse', 0, 'request','int');
		if ($ab!=1) return;
		
		$this->_getAdminLoggedIn();
		//set security token
		$token = $session->getFormToken();
		$_POST[$token]=1;
		
		//other ops
		if ($this->_isPro){
			$this->_proHelper->_otherOps();
		}
	}
	
	function getResult( $query ){
		$db	= JFactory::getDBO();

		$db->setQuery( $query );
		return $db->loadResult();
	}

	function doQuery( $query ){
		$db	= JFactory::getDBO();
		$db->setQuery( $query );

	    return $db->query();
	}

	function getRows( $query, $limitStart=0, $recs=0, $key='' ){
		$db	= JFactory::getDBO();

		if ( $recs > 0 ) {
			$db->setQuery( $query, $limitStart, $recs );
		}else{
			$db->setQuery( $query );
		}

		if ($key!=''){
			$rows = $db->loadObjectList($key);
		}else{
			$rows = $db->loadObjectList();
		}
		return $rows;
	}

	function getRow( $query ){
	    $rows = $this->getRows( $query );
		$row  = '';
		if ( count( $rows ) > 0 ) $row  = $rows[0];
		return $row;
	}
		
	function _debugje($str,$color='black',$bcolor='white'){
		$debugje	= JRequest::getVar('debugje', '', 'request');
		
		if ($debugje==1) {
			echo '<div style="color: '.$color.'; background-color: '.$bcolor.';padding:10px;">';
			echo $str.'<hr/>';
			echo '</div>';
		}
		
	}

}
