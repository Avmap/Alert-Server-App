jQuery(document).bind("mousemove",function(e){ 
	/*
		if (evadmGesturePos==1){
			if (e.clientX<=50 && e.clientY<=50) evadmbShow();
		}else if (evadmGesturePos==2){
			if (e.clientX>=jQuery(window).width()-50 && e.clientY<=50) evadmbShow();
		}else if (evadmGesturePos==3){
			if (e.clientX<=50 && e.clientY>=jQuery(window).height()-50) evadmbShow();
		}else if (evadmGesturePos==4){
			if (e.clientX>=jQuery(window).width()-50 && e.clientY>=jQuery(window).height()-50) evadmbShow();
		}
	*/
});

function evadbmIfmLoaded(){
	var u = jQuery("#evadmb_ifm").get(0).contentWindow.location;
	//alert(u);
	if (u=="about:blank") return;
	jQuery("#evadmb_ifm").attr("delay-src", u);
	//alert("wow!"+jQuery("#evadmb_ifm").attr("delay-src"));
	jQuery("#evadmb_ifm").css("width", "90%");
}

function evadmbShow() {
	if(jQuery("#evadmb-divmain").is(":visible")) return;
	
	var u = jQuery("#evadmb_ifm").get(0).contentWindow.location;
	
	//alert(jQuery("#evadmb_ifm").attr("src"));
	if (u!=jQuery("#evadmb_ifm").attr("delay-src")){
		jQuery("#evadmb_ifm").attr("src", jQuery("#evadmb_ifm").attr("delay-src"));
		//alert("reloading...");
	}else{
		jQuery("#evadmb_ifm").css("width", "90%");
	}
	
	vleft = (jQuery(window).width() *5/100);
	vtop  = (jQuery(window).height() * 5/100);
	vDivHeight = jQuery(window).height(); //* 90/100; 

    var ifm = jQuery("#evadmb_ifm");
    ifm.css({
        left: vleft,
        top: vtop
    });

    var ov = jQuery("#evadmb-divmain");
    
	if (evadmGesturePos==1){
		ov.css({left: 0,top: 0});		
	}else if (evadmGesturePos==2){
		ov.css({left: jQuery(window).width(),top: 0});		
	}else if (evadmGesturePos==3){
		ov.css({left:0,top:jQuery(window).height()});		
	}else if (evadmGesturePos==4){
		ov.css({left: jQuery(window).width(),top: jQuery(window).height()});		
	}else{
		ov.css({left: 0,top: 0});		
	}
	
    ov.css({
        width: 0,
        height: 0
    })
    .show()
    .animate({
        left: 0,
        top: 0,
        width: "100%",
        height: vDivHeight
        }, "slow");
}

function evadmbClose() {
	if(jQuery("#evadmb-divmain").is(":visible")){
		jQuery("#evadmb-divmain").hide("slow");
		jQuery("#evadmb_ifm").css("width", "0px");
	}
}
