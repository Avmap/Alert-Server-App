//joomgis.getPvt().controls.locate._activate();
jQuery.migrateMute=true;
joomgis.getPvt().map.setView([37.97,23.738],13);

function checkZoom(){
	var hash = window.location.hash.substr(1);
	var parts =  hash.split("&");
	if (parts.length==3){
		var lat=parseFloat(parts[0]);
		var lng=parseFloat(parts[1]);
		var title=parts[2];
		var zoom=false;
		if (window.mylat!=lat){
			window.mylat=lat;
			zoom=true;
		}
		if (window.mylng!=lng){
			window.mylng=lng;
			zoom=true;
		}
		if (window.mytitle!=title){
				window.mytitle=title;
		}
		if (zoom){
			joomgis.getPvt().map.setView([window.mylat,window.mylng],15);
			if (window.mymarker){
				window.mymarker.removeFrom(joomgis.getPvt().map);
			}
			
			window.mymarker=new window.L.Marker([window.mylat,window.mylng],{
				pane:'locationLayer',
				title: decodeURIComponent(window.mytitle),
				icon: L.icon({
					iconUrl: '/images/pointSymbols/alertMarker.png',
					iconSize: [50, 50],
					iconAnchor: [25, 50]
				})
			});
			window.mymarker.addTo(joomgis.getPvt().map);
		} 
		
			
		
	}else{
		if (window.mymarker){
			window.mymarker.removeFrom(joomgis.getPvt().map);
		}
	}
	
}
setInterval(checkZoom,2000);