importScripts("workbox-sw.js");
workbox.setConfig({ debug: false });
workbox.skipWaiting();
workbox.clientsClaim();

const apiCallHandler = new workbox.strategies.NetworkFirst({
  cacheName: 'app'
});
const tileserverCallHandler = new workbox.strategies.NetworkFirst({
  cacheName: 'tileserver'
});
const staticCaches = new workbox.strategies.NetworkFirst({
	cacheName: 'statics'
});

workbox.routing.registerRoute(
  new RegExp('/app.*'),
  apiCallHandler
);
workbox.routing.registerRoute(
  new RegExp('/tileserver[0-9]{0,2}.php.*'),
  tileserverCallHandler
);
workbox.routing.registerRoute(
  new RegExp('/map.*'),
  staticCaches
);

workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute([]);