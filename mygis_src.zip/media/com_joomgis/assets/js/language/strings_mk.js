﻿var joomgis_strings_mk = {
	langSuffix: '_mk',
	joomlaPrefix: 'mk',
	langTitle: 'Македонски',
	appName: 'MyGIS',
	appSlogan: 'Едноставно, лесно, брзо',
	geoLocateBtn: 'Гео-лоцирање',
	geoCodeBtn: 'Гео-код',
	searchBtn: 'Барај',
	layersBtn: 'Легенда',
	refreshBtn: 'Освежи',
	tableBtn: 'Табела',
	graphsBtn: 'На прв поглед',
	adminBtn: 'Управување',
	contactLoginBtn: 'Контакт',
	contactLogoutBtn: 'Поддршка',
	loginBtn: 'Логирај се',
	logoutBtn: 'Одјави се',
	offlineMsg: 'Вие сте исклучени. <br> MyGIS ќе продолжи да работи офлајн.',
	contactformTitle: 'Контакт',
	contactformNamePlaceholder: 'Целосно име и презиме',
	contactformTelephonePlaceholder: 'Телефон',
	contactformEmailPlaceholder: 'Е-пошта',
	contactformMessagePlaceholder: 'Порака',
	contactformSendBtn: 'Испрати',
	numGroup: '.',
	decimalsep: ',',
	common_km: 'km',
	common_meters: 'm',
	common_sqkm: 'km²',
	common_sqmeters: 'm²',
	common_totalLength: 'Вкупна должина',
	common_totalArea: 'Површина',
	common_segmentLength: 'Должина на сегментот',
	app_property:"Управување со сопственост",
	app_infodrasi:"Infodrasi Lite",
	menu_table: "Табела на атрибути",
	menu_tools: "Алатки",
	menu_about: "За",
	
	mapCategory:"",
	loginNotFilledIn: "Мора да го пополните корисничкото име и лозинката!",
	wrongLogin: "Погрешно корисничко име и лозинка",
	invalidToken: "Вашата сесија истече. Обидете се повторно да се поврзете",
	
	btnOK: "ΟΚ",
	btnCancel: "Откажи",
	windowConfirm: "Потврди",
	msgConfirmDefault: "Сигурен сум?",
	
	control_locate_title:"Моја локација",
	control_locate_popup: "Се наоѓате на {distance} {unit} од ова место",
	control_locate_outside:"Изгледа дека сте надвор од тековните граници на картата",
	
	controls_layer_base_cartoLight: "CartoMaps",
	controls_layer_base_googleStreets: "Google Roadmap",
	controls_layer_base_googleHybrid: "Google Hybrid",
	controls_layer_base_googleSat: "Google Satellite",
	controls_layer_base_googleTerrain: "Google Terrain",
	controls_layer_base_googleTraffic: "Google Traffic",
	controls_layer_base_ktimatologio: "Грчки катастар",
	
	controls_layer_base_groupname: "Позадина",
	controls_layer_overlayers_groupname: "Слоеви",
	
	control_geocoder_placeholder: "Пребарување на адреса",
	control_geocoder_errorMessage: "Не се пронајдени резултати",
	
	btn_filter_placeholder:"Барај",
	btn_sort_label: "Сортирај",
	noFeaturesOutsideExtent: "Ништо",
	editingChanges: "Има незачувани промени. Прво кликни зачувај или откажи",
	editSaveBtn: "Зачувај",
	editCancelBtn: "Откажи",
	editDeleteBtn: "Избриши",
	
	genericError: "Грешка: ",
	
	editResultSuccess: "Успешно зачувано",
	editResultError: "Грешка при зачувување, обидете се повторно",
	
	layerControl: "Легенда",
	searchControl: "Барај",
	layerVisibleBetween: "Слојот видлив помеѓу нивоата на зумирање {0} до {1}",
	styleVisibleBetween: "Тематски видливи помеѓу нивоата на зумирање {0} до {1}",
	currentlyAtZoom: "Тековното ниво на зумирање е {0}",
	tooltipDblClick: "Двоен клик за да биде видлив.",
	tooltipThematicIcon: "Тематски слој, кликни за да се прошири/собери",
	recordsFound1: "Вкупно: ",
	recordsFound2: "записи.",
	renderingSearchResults: "Анализа во тек...",
	groupingCheckBox: "Групирање",

	hideEmptyFields: "Сè",
	showMapLabel: "Мапа",
	infoSubtitleLabel: "Слој: ",
	info_editBtn: "Уреди",
	info_cancelEdit: "Поништи",
	info_saveEdit: "Зачувај",
	info_headerImages:"Слики",
	info_headerFiles:"Фајлови",
	info_btnClose:"Затвори",
	info_nodes: "Јазли",
	info_nodesHash: "#",
	info_nodesEGSAX: "Апсциса (Χ)",
	info_nodesEGSAY: "Ордината (Y)",
	info_nodesX: "Геогр. должина (λ)",
	info_nodesY: "Геогр. ширина (φ)",
	info_egsa: "GGRS87",
	info_wgs84: "WGS 84",
	infoZoomTo: "Зумирај мапа",
	infoExportPDF: "Извади во PDF",
	
	tooltip_layer: "Слој: ",
	
	newRecord: "Нов запис",
	BOOLEAN_YES: "ДА",
	BOOLEAN_NO: "НЕ",
	
	attribute_windowTitle:"",
	excel_FOOTER_SITE:"&amp;L&amp;26&amp;B",
	excel_FOOTER_TEXT:"&amp;LMyGIS.GR: Развиен од AVMap GIS Α.Ε.&amp;R&amp;P/&amp;N",
	pdf_DOCTITLE: 'Печатено со MyGIS.GR',
	pdf_DOCAUTHOR: 'https://mygis.gr/',
	pdf_DOCCREATOR: 'https://mygis.gr/',
	pdf_DOCPRODUCER: 'https://mygis.gr/',
	pdf_FOOTER_TEXT: 'Развиен од AVMap GIS Α.Ε.',
	pdf_pagesText: 'страница ',
	mygisLOGOENCODED: '',
	
	mapPrintBtn: 'Печати мапа',
	
	printOptions_title: 'Опции за печатење',
	printOptions_legend: 'Слој',
	printOptions_scale: 'Скала',
	printOptions_landscape: 'Landscape',
	printOptions_papersize: 'Големина на хартија',
	printOptions_contentTitle: 'Наслов',
	printOptions_contentSubtitle: 'Поднаслов',
	printOptions_btnGo: 'Печати',
	
	
	brandName: "MyGIS.GR",
	copyrights: "Развиен од <a href='http//www.avmap.gr/'>AVMap GIS Α.Ε.</a>",
	
	chartsWindowTitle: "На прв поглед",
	attributeSaveMatching: "Зачувај совпаѓање",
	attributeCancelMatching: "Откажи",
	attributeMatchedOutOf: "({0} од {1} избрани)",
	attributeVisibleOnly: "Во границите на картата",
	attributeSelectedOnlyBtn: "Само избраните",
	attributeExportPDF: "Извади во PDF",
	attributeAddRow: "Додај",
	attributeDeleteRow: "Избриши ги избраните",
	
	externalLayerLoaded: "Слој '{0}' вчитан.",
	notGeographicLayer: "не е географски слој",
	layerNotCurrentlyVisible: "Слојот не е видлив",
	needsUpdate: "---Потребно е ажурирање---",
	
	certificateBtnGo: "Креирај",
	certificateBtnEdit: "Уреди",
	certificateBtnDelete: "Избриши",
	certificateBtnView: "Приказ за печатење",
	certificateTitle: "Изврши печатење",
	certificateBtnDownload: "Кликнете тука за да преземете",
	
	info_certificates: "Печати",
	certificates_locateInfo: "Приказ на информации за објектот",
	certificates_createdOn: "Датум/Време",
	certificates_templateName: "Шаблон",
	certificates_byUser: "Корисник",
	certificates_params: "Параметри",
	certificates_actions: "Акции",
	certificates_new: "Ново",
	certificates_downloadInitial: "Преземи",
	certificates_StoreSuccess: "Печатењето е зачувано",
	certificates_TemplateStoreSuccess: "Шаблонот беше зачуван",
	certificateCreationTitle: "Креирај нов образец за печатење",
	certificateCreationGO: "Зачувај",
	certificateCreationCancel: "Откажи",
	certificates_newTemplate: "Додај шаблон",
	certificates_headerCreation: "Наслов",
	certificates_bodyCreation: "Текст",
	certificates_nameCreation: "Име на шаблонот",
	defaultCertName: "Мојот принт",
	certificates_tooltip_name: "Името на принтот е видливо само за вас, за да ви помогне да изберете помеѓу повеќе принтови за исто ниво. На пример, \"потврда за сопственост\", \"извештај за градежни блокови\" итн.",
	certificates_tooltip_header: "Насловот на принтот ќе се повторува на сите печатени страници.",
	certificates_tooltip_body: "Текстот на принтот.",
	certificates_tooltip_userVariable1: "Внесете <b> {(Променливо име)} </ b> за да внесете ваша променлива во принтот. Во секој принт, треба да ја вметнете оваа променлива.",
	certificates_tooltip_userVariable2: "Внесете <b> {{Променливо име $$ променлива вредност}} </ b> за да вметнете променлива во принтот со зададена вредност што можете да ја промените ако сакате.",
	certificates_tooltip_insertMyGIS1: "Кликнете на иконата ",
	certificates_tooltip_insertMyGIS2: " за да вметнете системска променлива (на пр. мапа или поле за слој).",
	certTemplate_id: "ID",
	certTemplate_name: "Име",
	certTemplate_created: "Креиран",
	certTemplate_createdUser: "Уредник",
	certTemplate_modified: "Изменето",
	certTemplate_modifiedUser: "Од",
	certTemplate_actions: "Акции",
	certificateManagementTitle: "Управување со шаблони",
	certTemplate_edit: "Уредување шаблони",
	certTemplate_delete: "Бришење шаблони",
	certTemplate_deleted: "Шаблонот е избришан",
	certTemplate_templateInUse: "Шаблонот не може да се избрише затоа што е користен. Сите принтови прво мора да бидат избришани.",
	certTemplate_manageCerts: "Погледнете ги сите принтови создадени со овој образец",
	certificatePrintManagementTitle: "Ппринтови со шаблон ",
	certificate_deleted: "Принтот е избришан",
	certificates_headerHeight: "Висина на насловот",
	
	context_centerMapHere: "Центрирај мапа овде",
	context_zoomInHere: "Зумирај тука",
	context_zoomOutHere: "Смали тука",
	context_selectAllHere: "Селектирај се",
	context_toggleDrawing: "Слободен избор",
	
	mapSelection: "Избор на мапа",
	mapSelectionTipsTitle: "",
	mapSelectionTipsDesc: "Држете го левото копче на глувчето за слободно да цртате.",
	mapSelectionCmpl: "ESC за да го исчистите изборот",

	noResults: "Не се пронајдени резултати",
	
	ExportDropDown: "Експортирај",
	printTemplates: {
		title01: "Мапа",
		descr01: "Вметнува тековна мапа, во центарот на избраниот објект.",
		title02: "Поле",
		descr02: "Вметнува поле од избраниот објект. Изберете од паѓачкото мени што се појавува.",
		title02a: "Автоматски поврзана табела",
		descr02a: "Вметнува записи кои се автоматски поврзани (поврзана табела). Изберете од паѓачкото мени што се појавува.",
		title02b: "Корисничко придружна табела",
		descr02b: "Вметнува записи кои се рачно поврзани  (корисничко придружна табела). Изберете од паѓачкото мени што се појавува.",
		title02c: "Координати (Грчка мрежа)",
		descr02c: "Вметнува координати на темињата на објектот (Грчка мрежа) во табеларна форма.",
		title02d: "Координати (WGS84)",
		descr02d: "Вметнува координати на темињата на објектот (WGS84) во табеларна форма.",
		title02e: "Слики",
		descr02e: "Ги вметнува поврзаните слики на селектираниот објект",
		title03: "Површина",
		descr03: "Областа на избраниот објект во метри.",
		title04: "Центроид",
		descr04: "Центроид на избраниот објект.",
		title05: "Должина",
		descr05: "Должината на избраниот објект во метри. Ако слојот не е линеарен тој ќе се врати на 0.",
		title06: "Периметар",
		descr06: "Периметарот на избраниот објект во метри. Ако слојот не е полигонален тој ќе се врати на 0.",
		title07: "Датум",
		descr07: "Внеси го тековниот датум за време на печатењето",
		title08: "Време",
		descr08: "Внеси го тековното време за време на печатењето"
	},
	gridLocale: {
		'/': "/", // separator of parts of a date (e.g. '/' in 11/05/1955)
		':': ":", // separator of parts of a time (e.g. ':' in 05:44 PM)
		firstDay: 0, // the first day of the week (0 = Sunday, 1 = Monday, etc)
		days: {
			names: ["Недела", "Понеделник", "Вторник", "Среда", "Четврток", "Петок", "Сабота"], // full day names
			namesAbbr: ["Нед", "Пон", "Вто", "Сре", "Чет", "Пет", "Саб"], // abbreviated day names
			namesShort: ["Не", "По", "Вт", "Ср", "Че", "Пе", "Са"]		// shortest day names
		},
		months: {
			names: ["Јануари", "Февруари", "Март", "Април", "Мај", "Јуни", "Јули", "Август", "Септември", "Октомври", "Ноември", "Декември", ""], // full month names (13 months for lunar calendards -- 13th month should be "" if not lunar)
			namesAbbr: ["Јан", "фев", "Мар", "Апр", "Мај", "Јун", "Јул", "Авг", "Сеп", "Окт", "Ное", "Дек", ""] // abbreviated month names
		},
		// AM and PM designators in one of these forms:
		// The usual view, and the upper and lower case versions
		// [standard,lowercase,uppercase]
		// The culture does not use AM or PM (likely all standard date formats use 24 hour time)
		// null
		AM: ["AM", "am", "AM"],
		PM: ["PM", "pm", "PM"],
		eras: [
			// eras in reverse chronological order.
			// name: the name of the era in this culture (e.g. A.D., C.E.)
			// start: when the era starts in ticks (gregorian, gmt), null if it is the earliest supported era.
			// offset: offset in years from gregorian calendar
			{"name": "π.Χ.", "start": null, "offset": 0 }
		],
		twoDigitYearMax: 2029,
		patterns: {
			// short date pattern
			d: "d/Μ/yyyy",
			// long date pattern
			D: "dddd, MMMM dd, yyyy",
			// short time pattern
			t: "h:mm tt",
			// long time pattern
			T: "h:mm:ss tt",
			// long date, short time pattern
			f: "dddd, MMMM dd, yyyy h:mm tt",
			// long date, long time pattern
			F: "dddd, MMMM dd, yyyy h:mm:ss tt",
			// month/day pattern
			M: "MMMM dd",
			// month/year pattern
			Y: "yyyy MMMM",
			// S is a sortable format that does not vary by culture
			S: "yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss"
		},
		percentsymbol: "%",
		currencysymbol: "€",
		currencysymbolposition: "after",
		decimalseparator: ',',
		thousandsseparator: '.',
		pagergotopagestring: "Одете на стр.:",
		pagershowrowsstring: "Прикажи записи:",
		pagerrangestring: " од ",
		pagerpreviousbuttonstring: "претходно",
		pagernextbuttonstring: "следно",
		groupsheaderstring: "Повлечете колона тука за групирање",
		sortascendingstring: "Растечко сортирање",
		sortdescendingstring: "Опаѓачко сортирање",
		sortremovestring: "Отстрани сортирање",
		groupbystring: "Групај според ова",
		groupremovestring: "Отстрани од групите",
		filterclearstring: "Исчисти",
		filterstring: "Филтрирај",
		filtershowrowstring: "Прикажи ги записите каде што:",
		filterorconditionstring: "Или",
		filterandconditionstring: "И",
		filterselectallstring: "(Прикажи ги сите)",
		filterchoosestring: "Ве молиме изберете:",
		filterstringcomparisonoperators: ['нула', 'не е нула', 'содржи', 'содржи(case sensitive)', 'не содржи', 'не содржи(case sensitive)', 'започнува со', 'започнува со(case sensitive)', 'завршува со', 'завршува со(case sensitive)', 'еднаков', 'еднаков(case sensitive)', 'нула', 'не е нула'],
		filternumericcomparisonoperators: ['еднаква', 'не е еднаква', 'помала од', 'помала или еднаква на', 'поголема од', 'поголема или еднаква на', 'нула', 'не е нула'],
		filterdatecomparisonoperators: ['еднаква', 'не е еднаква', 'помала од', 'помала или еднаква на', 'поголема од', 'поголема или еднаква на', 'нула', 'не е нула'],
		filterbooleancomparisonoperators: ['еднаква', 'не е еднаква'],
		validationstring: "Вметната вредност не е валидна"
	},
	
	L_drawLocal: {
		draw: {
			toolbar: {
				// #TODO: this should be reorganized where actions are nested in actions
				// ex: actions.undo  or actions.cancel
				actions: {
					// title: 'Откажи уредување',
					text: 'Откажи'
				},
				finish: {
					// title: 'Уредувањето е завршено',
					text: 'Откажи'
				},
				undo: {
					// title: 'Избришете ја последната точка',
					text: 'Избришете ја последната точка'
				},
				buttons: {
					polyline: 'Уреди линија',
					polygon: 'Уреди полигон',
					rectangle: 'Уреди правоаголник',
					circle: 'Уреди круг',
					marker: 'Уреди точка',
					circlemarker: 'Уреди кружен маркер'
				}
			},
			handlers: {
				circle: {
					tooltip: {
						start: 'Кликнете и влечете за да креирате кругот.'
					},
					radius: 'Радиус'
				},
				circlemarker: {
					tooltip: {
						start: 'Кликнете на мапата за да го поставите кружниот маркер.'
					}
				},
				marker: {
					tooltip: {
						start: 'Кликнете на мапата за да ја поставите точката.'
					}
				},
				polygon: {
					tooltip: {
						start: 'Кликнете за да започнете со уредување.',
						cont: 'Кликнете за да продолжите со уредувањето.',
						end: 'Кликнете на почетната точка за да завршите со уредувањето.'
					}
				},
				polyline: {
					error: '<strong>Грешка:</strong>темињата не можат да се пресекуваат!',
					tooltip: {
						start: 'Кликнете за да започнете со уредување.',
						cont: 'Кликнете за да продолжите со уредувањето.',
						end:  'Кликнете на последната точка за да завршите со уредувањето.'
					}
				},
				rectangle: {
					tooltip: {
						start: 'Кликнете и влечете за да креирате правоаголник.'
					}
				},
				simpleshape: {
					tooltip: {
						end: ' Пуштете го глувчето за да завршите со уредувањето.'
					}
				}
			}
		},
		edit: {
			toolbar: {
				actions: {
					save: {
						title: 'Зачувај ги промените',
						text: 'Зачувај'
					},
					cancel: {
						title: 'Откажи го уредувањето, промените ќе бидат изгубени',
						text: 'Откажи'
					},
					clearAll:{
						title: 'Избриши ги сите слоеви на уредување',
						text: 'Избриши се'
					}
				},
				buttons: {
					edit: 'Уредување на слој',
					editDisabled: 'Нема слоеви за уредување',
					remove: 'Избриши ги уредувачките слоеви',
					removeDisabled: 'Нема слоеви за бришење'
				},
				messages: {
					saved: 'Промените се зачувани',
					error: 'Настана грешка. Обидете се повторно подоцна!'
				}
			},
			handlers: {
				edit: {
					tooltip: {
						text: 'Повлечете ги точките или полињата за да уредувате вредности.',
						subtext: 'Кликнете Откажи за да ги вратите промените.'
					}
				},
				remove: {
					tooltip: {
						text: 'Кликнете на функцијата за да ја отстраните.'
					}
				}
			}
		}
	},
	
	error: {
		loginExpired: "Сесијата е истечена, поврзете се повторно",
		joinedLayerNotConfigured: "Соодветната дефиниција на табелата не беше пронајдена во mygis",
	}
	
};