﻿var joomgis_strings_gr = {
	langSuffix: '',
	joomlaPrefix: 'el',
	langTitle: 'Ελληνικά',
	appName: 'MyGIS',
	appSlogan: 'Απλά, εύκολα και γρήγορα',
	geoLocateBtn: 'Γεω-εντοπισμός',
	geoCodeBtn: 'Εύρεση διεύθυνσης',
	searchBtn: 'Αναζήτηση',
	layersBtn: 'Υπόμνημα',
	refreshBtn: 'Ανανέωση',
	tableBtn: 'Πίνακας',
	graphsBtn: 'Με μια ματιά',
	adminBtn: 'Διαχείριση',
	contactLoginBtn: 'Επικοινωνία',
	contactLogoutBtn: 'Υποστήριξη',
	loginBtn: 'Σύνδεση',
	logoutBtn: 'Αποσύνδεση',
	offlineMsg: 'Έχετε αποσυνδεθεί από το Internet.<br>Το MyGIS θα συνεχίσει να λειτουργεί με τα δεδομένα που έχετε ήδη κατεβάσει.',
	contactformTitle: 'Επικοινωνία',
	contactformNamePlaceholder: 'Ονοματεπώνυμο',
	contactformTelephonePlaceholder: 'Τηλέφωνο',
	contactformEmailPlaceholder: 'Email',
	contactformMessagePlaceholder: 'Μήνυμα',
	contactformSendBtn: 'Αποστολή',
	numGroup: '.',
	decimalsep: ',',
	common_km: 'χλμ',
	common_meters: 'μ',
	common_sqkm: 'χλμ²',
	common_sqmeters: 'μ²',
	common_totalLength: 'Συνολικό μήκος',
	common_totalArea: 'Εμβαδόν',
	common_segmentLength: 'Μήκος τμήματος',
	app_property:"Property Management",
	app_infodrasi:"Infodrasi Lite",
	menu_table: "Attribute Table",
	menu_tools: "Tools",
	menu_about: "About",
	
	mapCategory:"",
	loginNotFilledIn: "Πρέπει να συμπληρώσετε όνομα χρήστη και κωδικό!",
	wrongLogin: "Λάθος στοιχεία χρήστη",
	invalidToken: "Η συνεδρία σας έχει λήξει. Δοκιμάστε να ξανασυνδεθείτε",
	
	btnOK: "ΟΚ",
	btnCancel: "Ακύρωση",
	windowConfirm: "Επιβεβαίωση",
	msgConfirmDefault: "Είστε σίγουροι;",
	
	control_locate_title:"Η τοποθεσία μου",
	control_locate_popup:"Είστε εντός {distance} {unit} από αυτό το σημείο",
	control_locate_outside:"Φαίνεται ότι είστε εκτός ορίων του τρέχοντος χάρτη",
	
	controls_layer_base_cartoLight: "CartoMaps",
	controls_layer_base_googleStreets: "Οδικός Google",
	controls_layer_base_googleHybrid: "Υβριδικός Google",
	controls_layer_base_googleSat: "Δορυφορική Google",
	controls_layer_base_googleTerrain: "Ανάγλυφο Google",
	controls_layer_base_googleTraffic: "Κίνηση δρόμων Google",
	controls_layer_base_ktimatologio: "Κτηματολόγιο ΕΚΧΑ",
	
	controls_layer_base_groupname: "Υπόβαθρο",
	controls_layer_overlayers_groupname: "Επίπεδα",
	
	control_geocoder_placeholder: "Αναζήτηση διεύθυνσης",
	control_geocoder_errorMessage: "Δεν βρέθηκαν αποτελέσματα",
	
	btn_filter_placeholder:"Αναζήτηση",
	btn_sort_label: "Ταξινόμηση",
	noFeaturesOutsideExtent: "Κανένα",
	editingChanges: "Υπάρχουν αλλαγές που δεν έχουν αποθηκευτεί. Πατήστε αποθήκευση ή ακύρωση πρώτα",
	editSaveBtn: "Αποθήκευση",
	editCancelBtn: "Ακύρωση",
	editDeleteBtn: "Διαγραφή",
	
	genericError: "Σφάλμα: ",
	
	editResultSuccess: "Επιτυχής αποθήκευση",
	editResultError: "Σφάλμα κατά την αποθήκευση, δοκιμάστε ξανά",
	
	layerControl: "Υπόμνημα",
	searchControl: "Αναζήτηση",
	layerVisibleBetween: "Επίπεδο ορατό σε zoom {0} έως {1}",
	styleVisibleBetween: "Θεματικός σε zoom {0} έως {1}",
	currentlyAtZoom: "Τρέχον zoom το {0}",
	tooltipDblClick: "Διπλό κλικ για να γίνει ορατό.",
	tooltipThematicIcon: "Το επίπεδο έχει θεματική απεικόνιση, κλικ για ανάπτυξη/σύμπτυξη",
	recordsFound1: "Σύνολο: ",
	recordsFound2: "εγγραφές.",
	renderingSearchResults: "Ανάλυση σε εξέλιξη...",
	groupingCheckBox: "Ομάδες",

	hideEmptyFields: "Όλα",
	showMapLabel:"Χάρτης",
	infoSubtitleLabel: "Επίπεδο: ",
	info_editBtn: "Επεξεργασία",
	info_cancelEdit: "Ακύρωση",
	info_saveEdit: "Αποθήκευση",
	info_headerImages:"Εικόνες",
	info_headerFiles:"Αρχεία",
	info_btnClose:"Κλείσιμο",
	info_nodes: "Συντεταγμένες",
	info_nodesHash: "#",
	info_nodesEGSAX: "Τετμημένη (Χ)",
	info_nodesEGSAY: "Τεταγμένη (Y)",
	info_nodesX: "Γεωγρ. μήκος (λ)",
	info_nodesY: "Γεωγρ. πλάτος (φ)",
	info_egsa: "ΕΓΣΑ 87",
	info_wgs84: "WGS 84",
	infoZoomTo: "Εστίαση χάρτη",
	infoExportPDF: "Εξαγωγή PDF",
	
	tooltip_layer: "Επίπεδο: ",
	
	newRecord: "Νέα καταχώρηση",
	BOOLEAN_YES: "ΝΑΙ",
	BOOLEAN_NO: "ΟΧΙ",
	
	attribute_windowTitle:"",
	excel_FOOTER_SITE:"&amp;L&amp;26&amp;B",
	excel_FOOTER_TEXT:"&amp;LMyGIS.GR: Αναπτύχθηκε από την AVMap GIS Α.Ε.&amp;R&amp;P/&amp;N",
	pdf_DOCTITLE: 'Εκτύπωση από MyGIS.GR',
	pdf_DOCAUTHOR: 'https://mygis.gr/',
	pdf_DOCCREATOR: 'https://mygis.gr/',
	pdf_DOCPRODUCER: 'https://mygis.gr/',
	pdf_FOOTER_TEXT: 'Αναπτύχθηκε από την AVMap GIS Α.Ε.',
	pdf_pagesText: 'σελ. ',
	mygisLOGOENCODED: '',
	
	mapPrintBtn: 'Εκτύπωση χάρτη',
	
	printOptions_title: 'Επιλογές εκτύπωσης',
	printOptions_legend: 'Υπόμνημα',
	printOptions_scale: 'Κλίμακα',
	printOptions_landscape: 'Landscape',
	printOptions_papersize: 'Μέγεθος χαρτιού',
	printOptions_contentTitle: 'Τίτλος',
	printOptions_contentSubtitle: 'Υπότιτλος',
	printOptions_btnGo: 'Εκτύπωση',
	
	
	brandName: "MyGIS.GR",
	copyrights: "Αναπτύχθηκε από <a href='http://www.avmap.gr/'>AVMap GIS Α.Ε.</a>",
	
	chartsWindowTitle: "Με μια ματιά",
	attributeSaveMatching: "Αποθήκευση αντιστοίχησης",
	attributeCancelMatching: "Ακύρωση",
	attributeMatchedOutOf: "(Έχουν επιλεγεί {0} από {1})",
	attributeVisibleOnly: "Εντός ορίων χάρτη",
	attributeSelectedOnlyBtn: "Επιλεγμένα μόνο",
	attributeExportPDF: "Εξαγωγή PDF",
	attributeAddRow: "Προσθήκη",
	attributeDeleteRow: "Διαγραφή επιλεγμένων",
	
	externalLayerLoaded: "Το επίπεδο '{0}' φορτώθηκε στον χάρτη.",
	notGeographicLayer: "Δεν έχει γεωγραφική πληροφορία",
	layerNotCurrentlyVisible: "Μη ορατό επίπεδο",
	needsUpdate: "---Χρειάζεται ενημέρωση---",
	
	certificateBtnGo: "Δημιουργία",
	certificateBtnEdit: "Επεξεργασία",
	certificateBtnDelete: "Διαγραφή",
	certificateBtnView: "Προβολή εκτυπώσεων",
	certificateTitle: "Παραγωγή εκτύπωσης",
	certificateBtnDownload: "Πατήστε εδώ για να κατεβάσετε το αρχείο",
	
	info_certificates: "Εκτυπώσεις",
	certificates_locateInfo: "Προβολή πληροφοριών αντικειμένου",
	certificates_createdOn: "Ημ/νία Ώρα",
	certificates_templateName: "Πρότυπο",
	certificates_byUser: "Χρήστης",
	certificates_params: "Παράμετροι",
	certificates_actions: "Ενέργειες",
	certificates_new: "Νέα",
	certificates_downloadInitial: "Κατέβασμα",
	certificates_StoreSuccess: "Η εκτύπωση αποθηκεύτηκε",
	certificates_TemplateStoreSuccess: "Το πρότυπο αποθηκεύτηκε",
	certificateCreationTitle: "Δημιουργία προτύπου εκτύπωσης",
	certificateCreationGO: "Αποθήκευση",
	certificateCreationCancel: "Ακύρωση",
	certificates_newTemplate: "Προσθήκη προτύπου",
	certificates_headerCreation: "Επικεφαλίδα",
	certificates_bodyCreation: "Κείμενο",
	certificates_nameCreation: "Όνομα προτύπου",
	defaultCertName: "Η εκτύπωσή μου",
	certificates_tooltip_name: "Το όνομα της εκτύπωσης είναι ορατό μόνο σε εσάς, για να σας βοηθάει να επιλέξετε ανάμεσα σε πολλαπλές εκτυπώσεις για το ίδιο επίπεδο. Π.χ. 'βεβαίωση ιδιοκτησίας', 'αναφορά οικοδομικού τετραγώνου' κ.λ.π.",
	certificates_tooltip_header: "Η επικεφαλίδα της εκτύπωσης θα επαναλαμβάνεται σε όλες τις σελίδες της παραχθείσας εκτύπωσης.",
	certificates_tooltip_body: "Το κείμενο της εκτύπωσης.",
	certificates_tooltip_userVariable1: "Πληκτρολογήστε <b>{{Όνομα μεταβλητής}}</b> για να εισάγετε μια δική σας μεταβλητή στην εκτύπωση. Κάθε φορά που θα παράγετε μια εκτύπωση θα πρέπει να συμπληρώνετε αυτή την μεταβλητή.",
	certificates_tooltip_userVariable2: "Πληκτρολογήστε <b>{{Όνομα μεταβλητής$$Τιμή μεταβλητής}}</b> για να εισάγετε μια μεταβλητή στην εκτύπωση, με προκαθορισμένη τιμή την οποία θα μπορείτε να αλλάζετε αν το επιθυμείτε.",
	certificates_tooltip_insertMyGIS1: "Κάντε κλικ στο εικονίδιο ",
	certificates_tooltip_insertMyGIS2: " για να εισάγετε μια μεταβλητή συστήματος (π.χ. χάρτη, ή κάποιο πεδίο του επιπέδου).",
	certTemplate_id: "ID",
	certTemplate_name: "Ονομασία",
	certTemplate_created: "Δημιουργήθηκε",
	certTemplate_createdUser: "Δημιουργός",
	certTemplate_modified: "Τροποποιήθηκε",
	certTemplate_modifiedUser: "Από",
	certTemplate_actions: "Ενέργειες",
	certificateManagementTitle: "Διαχείριση προτύπων",
	certTemplate_edit: "Επεξεργασία προτύπου",
	certTemplate_delete: "Διαγραφή προτύπου",
	certTemplate_deleted: "Το πρότυπο διαγράφηκε",
	certTemplate_templateInUse: "Το πρότυπο δε μπορεί να διαγραφεί γιατί έχει χρησιμοποιηθεί. Θα πρέπει να διαγραφούν πρώτα όλες οι εκτυπώσεις",
	certTemplate_manageCerts: "Δείτε τις εκτυπώσεις που έχουν δημιουργηθεί με αυτό το πρότυπο",
	certificatePrintManagementTitle: "Εκτυπώσεις με το πρότυπο ",
	certificate_deleted: "Η εκτύπωση διαγράφηκε",
	certificates_headerHeight: "Ύψος επικεφαλίδας",
	
	context_centerMapHere: "Εστίαση εδώ",
	context_zoomInHere: "Μεγέθυνση εδώ",
	context_zoomOutHere: "Σμίκρυνση από εδώ",
	context_selectAllHere: "Επιλογή όλων",
	context_toggleDrawing: "Ελεύθερος σχεδιασμός",
	
	mapSelection: "Επιλογή από χάρτη",
	mapSelectionTipsTitle: "",
	mapSelectionTipsDesc: "Ελεύθερη σχεδίαση με πατημένο το αριστερό πλήκτρο του ποντικιού.",
	mapSelectionCmpl: "ESC για καθαρισμό της επιλογής",

	noResults: "Δεν βρέθηκαν αποτελέσματα",
	
	ExportDropDown: "Εξαγωγή",
	printTemplates: {
		title01: "Χάρτης",
		descr01: "Εισάγει τον τρέχοντα χάρτη, κεντραρισμένο στο επιλεγμένο αντικείμενο.",
		title02: "Πεδίο",
		descr02: "Εισάγει κάποιο πεδίο από το επιλεγμένο αντικείμενο. Επιλέξτε από το dropdown που εμφανίζεται.",
		title02a: "Αυτόματα συνδεδεμένος πίνακας",
		descr02a: "Εισάγει τις εγγραφές που έχουν συνδεθεί αυτόματα (joined πίνακας). Επιλέξτε από το dropdown που εμφανίζεται.",
		title02b: "Χειροκίνητα-συνδεδεμένος πίνακας",
		descr02b: "Εισάγει τις εγγραφές που έχουν συνδεθεί χειροκίνητα (user-joined πίνακας). Επιλέξτε από το dropdown που εμφανίζεται.",
		title02c: "Συντεταγμένες (ΕΓΣΑ)",
		descr02c: "Εισάγει τις συντεταγμένες των κορυφών του αντικειμένου (ΕΓΣΑ) σε μορφή πίνακα.",
		title02d: "Συντεταγμένες (WGS84)",
		descr02d: "Εισάγει τις συντεταγμένες των κορυφών του αντικειμένου (WGS84) σε μορφή πίνακα.",
		title02e: "Εικόνες",
		descr02e: "Εισάγει τις συνδεδεμένες εικόνες του επιλεγμένου αντικειμένου",
		title03: "Εμβαδόν",
		descr03: "Το εμβαδόν του επιλεγμένου αντικειμένου σε μέτρα.",
		title04: "Κεντροειδές",
		descr04: "Το κεντροειδές του επιλεγμένου αντικειμένου.",
		title05: "Μήκος",
		descr05: "Το μήκος του επιλεγμένου αντικειμένου σε μέτρα. Αν το επίπεδο δεν είναι γραμμικό, θα επιστρέψει 0.",
		title06: "Περίμετρος",
		descr06: "Η περίμετρος του επιλεγμένου αντικειμένου σε μέτρα. Αν το επίπεδο δεν είναι πολυγωνικό, θα επιστρέψει 0.",
		title07: "Ημ/νία",
		descr07: "Εισάγει την τρέχουσα ημ/νία κατά την παραγωγή της εκτύπωσης",
		title08: "Ώρα",
		descr08: "Εισάγει την τρέχουσα ώρα κατά την παραγωγή της εκτύπωσης"
	},
	gridLocale: {
		'/': "/", // separator of parts of a date (e.g. '/' in 11/05/1955)
		':': ":", // separator of parts of a time (e.g. ':' in 05:44 PM)
		firstDay: 0, // the first day of the week (0 = Sunday, 1 = Monday, etc)
		days: {
			names: ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"], // full day names
			namesAbbr: ["Κυρ", "Δευ", "Τρι", "Τετ", "Πεμ", "Παρ", "Σαβ"], // abbreviated day names
			namesShort: ["Κυ", "Δε", "Τρ", "Τε", "Πε", "Πα", "Σα"]		// shortest day names
		},
		months: {
			names: ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος", ""], // full month names (13 months for lunar calendards -- 13th month should be "" if not lunar)
			namesAbbr: ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαϊ", "Ιούν", "Ιούλ", "Αυγ", "Σεπ", "Οκτ", "Νοε", "Δεκ", ""] // abbreviated month names
		},
		// AM and PM designators in one of these forms:
		// The usual view, and the upper and lower case versions
		// [standard,lowercase,uppercase]
		// The culture does not use AM or PM (likely all standard date formats use 24 hour time)
		// null
		AM: ["ΠΜ", "πμ", "ΠΜ"],
		PM: ["ΜΜ", "μμ", "ΜΜ"],
		eras: [
			// eras in reverse chronological order.
			// name: the name of the era in this culture (e.g. A.D., C.E.)
			// start: when the era starts in ticks (gregorian, gmt), null if it is the earliest supported era.
			// offset: offset in years from gregorian calendar
			{"name": "π.Χ.", "start": null, "offset": 0 }
		],
		twoDigitYearMax: 2029,
		patterns: {
			// short date pattern
			d: "d/Μ/yyyy",
			// long date pattern
			D: "dddd, MMMM dd, yyyy",
			// short time pattern
			t: "h:mm tt",
			// long time pattern
			T: "h:mm:ss tt",
			// long date, short time pattern
			f: "dddd, MMMM dd, yyyy h:mm tt",
			// long date, long time pattern
			F: "dddd, MMMM dd, yyyy h:mm:ss tt",
			// month/day pattern
			M: "MMMM dd",
			// month/year pattern
			Y: "yyyy MMMM",
			// S is a sortable format that does not vary by culture
			S: "yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss"
		},
		percentsymbol: "%",
		currencysymbol: "€",
		currencysymbolposition: "after",
		decimalseparator: ',',
		thousandsseparator: '.',
		pagergotopagestring: "Μετάβαση σε σελ.:",
		pagershowrowsstring: "Εμφάνιση γραμμών:",
		pagerrangestring: " από ",
		pagerpreviousbuttonstring: "προηγούμενη",
		pagernextbuttonstring: "επόμενη",
		groupsheaderstring: "Σύρετε μια στήλη εδώ για ομαδοποίηση",
		sortascendingstring: "Αυξ. ταξινόμηση",
		sortdescendingstring: "Φθίν. ταξινόμηση",
		sortremovestring: "Αφαίρεση ταξινόμησης",
		groupbystring: "Ομαδοποίηση κατά αυτή",
		groupremovestring: "Αφαίρεση από ομάδες",
		filterclearstring: "Καθαρισμός",
		filterstring: "Φιλτράρισμα",
		filtershowrowstring: "Εμφάνιση γραμμών όπου:",
		filterorconditionstring: "Ή",
		filterandconditionstring: "Και",
		filterselectallstring: "(Εμφάνιση όλων)",
		filterchoosestring: "Παρακαλώ επιλέξτε:",
		filterstringcomparisonoperators: ['κενό', 'όχι κενό', 'περιέχει', 'περιέχει(case sensitive)',
		'δεν περιέχει', 'δεν περιέχει(case sensitive)', 'ξεκινά με', 'ξεκινά με(case sensitive)',
		'τελειώνει με', 'τελειώνει με(case sensitive)', 'ίσο', 'ίσο(case sensitive)', 'κενό', 'όχι κενό'],
		filternumericcomparisonoperators: ['ίσο', 'όχι ίσο', 'μικρότερο από', 'μικρότερο ή ίσο από', 'μεγαλύτερο από', 'μεγαλύτερο ή ίσο από', 'κενό', 'όχι κενό'],
		filterdatecomparisonoperators: ['ίσο', 'όχι ίσο', 'μικρότερο από', 'μικρότερο ή ίσο από', 'μεγαλύτερο από', 'μεγαλύτερο ή ίσο από', 'κενό', 'όχι κενό'],
		filterbooleancomparisonoperators: ['ίσο', 'όχι ίσο'],
		validationstring: "Η εισαχθείσα τιμή δεν είναι έγκυρη"
	},
	
	L_drawLocal: {
		draw: {
			toolbar: {
				// #TODO: this should be reorganized where actions are nested in actions
				// ex: actions.undo  or actions.cancel
				actions: {
					// title: 'Ακύρωση ψηφιοποπίησης',
					text: 'Ακύρωση'
				},
				finish: {
					// title: 'Ολοκλήρωση ψηφιοποίησης',
					text: 'Ολοκλήρωση'
				},
				undo: {
					// title: 'Διαγραφή τελευταίου σημείου',
					text: 'Διαγραφή τελευταίου σημείου'
				},
				buttons: {
					polyline: 'Ψηφιοποίηση γραμμής',
					polygon: 'Ψηφιοποίηση πολυγώνου',
					rectangle: 'Ψηφιοποίηση ορθογωνίου',
					circle: 'Ψηφιοποίηση κύκλου',
					marker: 'Ψηφιοποίηση σημείου',
					circlemarker: 'Ψηφιοποίηση κυκλικού σημείου'
				}
			},
			handlers: {
				circle: {
					tooltip: {
						start: 'Κάντε κλικ και σύρετε για να ψηφιοποιήσετε κύκλο.'
					},
					radius: 'Ακτίνα'
				},
				circlemarker: {
					tooltip: {
						start: 'Κάντε κλικ στον χάρτη για να τοποθετήσετε το σημείο.'
					}
				},
				marker: {
					tooltip: {
						start: 'Κάντε κλικ στον χάρτη για να τοποθετήσετε το σημείο.'
					}
				},
				polygon: {
					tooltip: {
						start: 'Κάντε κλικ για έναρξη ψηφιοποίησης.',
						cont: 'Κάντε κλικ για να συνεχίσετε την ψηφιοποίηση.',
						end: 'Κάντε κλικ στο αρχικό σημείο για να ολοκληρώσετε το σχήμα.'
					}
				},
				polyline: {
					error: '<strong>Σφάλμα:</strong> οι ακμές του σχήματος δε γίνεται να διασταυρώνονται!',
					tooltip: {
						start: 'Κάντε κλικ για να έναρξη ψηφιοποίησης.',
						cont: 'Κάντε κλικ για να συνεχίσετε την ψηφιοποίηση.',
						end: 'Κάντε κλικ στο τελικό σημείο για να ολοκληρώσετε το σχήμα.'
					}
				},
				rectangle: {
					tooltip: {
						start: 'Κάντε κλικ και σύερετε για να ψηφιοποιήσετε ορθογώνιο.'
					}
				},
				simpleshape: {
					tooltip: {
						end: 'Αφήστε το ποντίκι για να ολοκληρώσετε το σχήμα.'
					}
				}
			}
		},
		edit: {
			toolbar: {
				actions: {
					save: {
						title: 'Αποθήκευση αλλαγών',
						text: 'Αποθήκευση'
					},
					cancel: {
						title: 'Ακύρωση επεξεργασίας, οι αλλαγές θα χαθούν',
						text: 'Ακύρωση'
					},
					clearAll:{
						title: 'Καθαρισμός όλων των επεξεργάσιμων επιπέδων',
						text: 'Καθαρισμός όλων'
					}
				},
				buttons: {
					edit: 'Επεξεργασία επιπέδων',
					editDisabled: 'Δεν υπάρχουν επεξεργάσιμα επίπεδα',
					remove: 'Διαγραφή επεξεργάσιμων επιπέδων',
					removeDisabled: 'Δεν υπάρχουν επίπεδα προς διαγραφή'
				},
				messages: {
					saved: 'Οι αλλαγές αποθηκεύτηκαν',
					error: 'Συνέβη κάποιο σφάλμα. Ξαναδοκιμάστε σε λίγο'
				}
			},
			handlers: {
				edit: {
					tooltip: {
						text: 'Σύρετε τα σημεία ή τα κουτάκια για να επεξεργαστείτε χαρακτηρστικά.',
						subtext: 'Κλικ στην ακύρωση για αναίρεση των αλλαγών.'
					}
				},
				remove: {
					tooltip: {
						text: 'Κλικ σε ένα χαρακτηριστικό για να αφαιρεθεί.'
					}
				}
			}
		}
	},
	
	error: {
		loginExpired: "Η συνεδρία έχει λήξει, ξανασυνδεθείτε",
		joinedLayerNotConfigured: "Δεν βρέθηκε ο ορισμός του συνδεδεμένου πίνακα στο mygis",
	}
	
};