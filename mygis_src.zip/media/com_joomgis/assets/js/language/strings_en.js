﻿var joomgis_strings_en = {
	langSuffix: '_en',
	joomlaPrefix: 'en',
	langTitle: 'English',
	'appName': 'MyGIS',
	'appSlogan': 'Simple, easy, fast',
	'geoLocateBtn': 'Geo-locate',
	'geoCodeBtn': 'Geo-code',
	'searchBtn': 'Search',
	'layersBtn': 'Legend',
	'refreshBtn': 'Refresh',
	'tableBtn': 'Table',
	'graphsBtn': 'At a glance',
	'adminBtn': 'Administration',
	'contactLoginBtn': 'Contact',
	'contactLogoutBtn': 'Support',
	'loginBtn': 'Login',
	'logoutBtn': 'Logout',
	'offlineMsg': 'You have been disconnected.<br>MyGIS will continue to work offline.',
	'contactformTitle': 'Contact',
	'contactformNamePlaceholder': 'Fullname',
	'contactformTelephonePlaceholder': 'Telephone',
	'contactformEmailPlaceholder': 'Email',
	'contactformMessagePlaceholder': 'Message',
	'contactformSendBtn': 'Send',
	numGroup: ',',
	decimalsep: '.',
	common_km: 'km',
	common_meters: 'm',
	common_sqkm: 'km²',
	common_sqmeters: 'm²',
	common_totalLength: 'Total length',
	common_totalArea: 'Area',
	common_segmentLength: 'Segment length',
	app_property:"Property Management",
	app_infodrasi:"Infodrasi Lite",
	menu_table: "Attribute Table",
	menu_tools: "Tools",
	menu_about: "About",
	
	mapCategory:"",
	loginNotFilledIn: "You must fill in username and password!",
	wrongLogin: "Wrong user/password",
	invalidToken: "Your session has expired. Try to reconnect",
	
	btnOK: "ΟΚ",
	btnCancel: "Cancel",
	windowConfirm: "Confirm",
	msgConfirmDefault: "Are you sure?",
	
	control_locate_title:"My location",
	control_locate_popup:"You are within {distance} {unit} from this spot",
	control_locate_outside:"You appear to be outside the current map's bounds",
	
	controls_layer_base_cartoLight: "CartoMaps",
	controls_layer_base_googleStreets: "Google Roadmap",
	controls_layer_base_googleHybrid: "Google Hybrid",
	controls_layer_base_googleSat: "Google Satellite",
	controls_layer_base_googleTerrain: "Google Terrain",
	controls_layer_base_googleTraffic: "Google Traffic",
	controls_layer_base_ktimatologio: "Greek Cadastre",
	
	controls_layer_base_groupname: "Background",
	controls_layer_overlayers_groupname: "Layers",
	
	control_geocoder_placeholder: "Address search",
	control_geocoder_errorMessage: "No results found",
	
	btn_filter_placeholder:"Search",
	btn_sort_label: "Sort",
	noFeaturesOutsideExtent: "None",
	editingChanges: "There are unsaved changes. Press save or discard first",
	editSaveBtn: "Save",
	editCancelBtn: "Cancel",
	editDeleteBtn: "Delete",
	
	genericError: "Error: ",
	
	editResultSuccess: "Successful save",
	editResultError: "Error during saving, try again",
	
	layerControl: "Legend",
	searchControl: "Search",
	layerVisibleBetween: "Layer visible between levels {0} to {1}",
	styleVisibleBetween: "Thematic visible between levels {0} to {1}",
	currentlyAtZoom: "Current zoom level is {0}",
	tooltipDblClick: "Double click to make it visible.",
	tooltipThematicIcon: "It's a thematic layer, click to expand/collapse",
	recordsFound1: "Total: ",
	recordsFound2: "records.",
	renderingSearchResults: "Analysis in progress...",
	groupingCheckBox: "Grouping",

	hideEmptyFields: "All",
	showMapLabel:"Map",
	infoSubtitleLabel: "Layer: ",
	info_editBtn: "Edit",
	info_cancelEdit: "Cancel",
	info_saveEdit: "Save",
	info_headerImages:"Images",
	info_headerFiles:"Files",
	info_btnClose:"Close",
	info_nodes: "Nodes",
	info_nodesHash: "#",
	info_nodesEGSAX: "Abscissa (Χ)",
	info_nodesEGSAY: "Ordinate (Y)",
	info_nodesX: "Longitude",
	info_nodesY: "Latitude",
	info_egsa: "Greek Grid",
	info_wgs84: "WGS 84",
	infoZoomTo: "Zoom map",
	infoExportPDF: "Export PDF",
	
	tooltip_layer: "Layer: ",
	
	newRecord: "New record",
	BOOLEAN_YES: "YES",
	BOOLEAN_NO: "NO",
	
	attribute_windowTitle:"",
	excel_FOOTER_SITE:"&amp;L&amp;26&amp;B",
	excel_FOOTER_TEXT:"&amp;LMyGIS.GR: Developed by AVMap GIS S.A.&amp;R&amp;P/&amp;N",
	pdf_DOCTITLE: 'Printed with MyGIS.GR',
	pdf_DOCAUTHOR: 'https://mygis.gr/',
	pdf_DOCCREATOR: 'https://mygis.gr/',
	pdf_DOCPRODUCER: 'https://mygis.gr/',
	pdf_FOOTER_TEXT: 'Developed by AVMap GIS S.A.',
	pdf_pagesText: 'page ',
	mygisLOGOENCODED: '',
	
	mapPrintBtn: 'Print map',
	
	printOptions_title: 'Print options',
	printOptions_legend: 'Layer',
	printOptions_scale: 'Scale',
	printOptions_landscape: 'Landscape',
	printOptions_papersize: 'Paper size',
	printOptions_contentTitle: 'Title',
	printOptions_contentSubtitle: 'Subtitle',
	printOptions_btnGo: 'Print',
	
	
	brandName: "MyGIS.GR",
	copyrights: "Developed by  <a href='http://www.avmap.gr/'>AVMap GIS S.A.</a>",
	
	chartsWindowTitle: "At a glance",
	attributeSaveMatching: "Save matching",
	attributeCancelMatching: "Cancel",
	attributeMatchedOutOf: "({0} out of {1} selected)",
	attributeVisibleOnly: "Within map limits",
	attributeSelectedOnlyBtn: "Selected only",
	attributeExportPDF: "Export PDF",
	attributeAddRow: "Add",
	attributeDeleteRow: "Delete selected",
	
	externalLayerLoaded: "Layer '{0}' loaded.",
	notGeographicLayer: "is not a geographic layer",
	layerNotCurrentlyVisible: "Not visible",
	needsUpdate: "---Needs update---",
	
	certificateBtnGo: "Create",
	certificateBtnEdit: "Edit",
	certificateBtnDelete: "Delete",
	certificateBtnView: "View prints",
	certificateTitle: "Execute print",
	certificateBtnDownload: "Click here to download",
	
	info_certificates: "Prints",
	certificates_locateInfo: "View object info",
	certificates_createdOn: "Date/Time",
	certificates_templateName: "Template",
	certificates_byUser: "User",
	certificates_params: "Parameters",
	certificates_actions: "Actions",
	certificates_new: "New",
	certificates_downloadInitial: "Download",
	certificates_StoreSuccess: "Print has been saved",
	certificates_TemplateStoreSuccess: "Template has been saved",
	certificateCreationTitle: "Create new print template",
	certificateCreationGO: "Save",
	certificateCreationCancel: "Cancel",
	certificates_newTemplate: "Add template",
	certificates_headerCreation: "Header",
	certificates_bodyCreation: "Body",
	certificates_nameCreation: "Template name",
	defaultCertName: "My print",
	certificates_tooltip_name: "The print name is visible only to you, in order to help you choose between multiple prints for the same layer. E.g. 'parcel certificate', 'city block report', etc",
	certificates_tooltip_header: "The print header will be repeated in all the printed pages.",
	certificates_tooltip_body: "The print text.",
	certificates_tooltip_userVariable1: "Type <b>{{Variable name}}</b> to insert your variable in the print. In every print you have to insert this variable.",
	certificates_tooltip_userVariable2: "Type <b>{{Variable name$$Variable value}}</b> to insert a variable in the print with dedfault value which you can change if you want.",
	certificates_tooltip_insertMyGIS1: "Click on the icon ",
	certificates_tooltip_insertMyGIS2: " to insert a system variable (e.g. map or a layer field).",
	certTemplate_id: "ID",
	certTemplate_name: "Name",
	certTemplate_created: "Created",
	certTemplate_createdUser: "Editor",
	certTemplate_modified: "Modified",
	certTemplate_modifiedUser: "By",
	certTemplate_actions: "Actions",
	certificateManagementTitle: "Template management",
	certTemplate_edit: "Template edit",
	certTemplate_delete: "Delete template",
	certTemplate_deleted: "The template is deleted",
	certTemplate_templateInUse: "The template can't be deleted because it has been used. All the prints must first be deleted.",
	certTemplate_manageCerts: "View all the prints created by this template",
	certificatePrintManagementTitle: "Prints with template ",
	certificate_deleted: "The print is deleted",
	certificates_headerHeight: "Header height",
	
	context_centerMapHere: "Center map here",
	context_zoomInHere: "Zoom in here",
	context_zoomOutHere: "Zoom out",
	context_selectAllHere: "Select all",
	context_toggleDrawing: "Free selection",
	
	mapSelection: "Map selection",
	mapSelectionTipsTitle: "",
	mapSelectionTipsDesc: "Hold down the left mouse button to freely draw.",
	mapSelectionCmpl: "ESC to clear selection",

	noResults: "No results",
	ExportDropDown: "Export",
	printTemplates: {
		title01: "Map",
		descr01: "Inserts current map, centred to the selected item.",
		title02: "Field",
		descr02: "Inserts a field from the selected item. Choose from the drop-down list shown.",
		title02a: "Automatically joined table",
		descr02a: "Inserts the records that have automatically be joined (joined table). Choose from the drop-down list shown.",
		title02b: "User joined table",
		descr02b: "Inserts the records that have manually be joined (user joined table). Choose from the drop-down list shown.",
		title02c: "Greek Grid coordinates",
		descr02c: "Inserts the coordinates of item vertices (Greek Grid) in table form.",
		title02d: "Coordinates (WGS84)",
		descr02d: "Inserts the coordinates of item vertices (WGS84) in table form.",
		title02e: "Images",
		descr02e: "Inserts joined images of the selected item",
		title03: "Area",
		descr03: "Area of the selected item in meters.",
		title04: "Centroid",
		descr04: "The centroid of the selected item.",
		title05: "Length",
		descr05: "The length of the selected item in meters. If the layer is not linear, 0 will be returned.",
		title06: "Perimeter",
		descr06: "The perimeter of the selected item in meters. If the layer is not polygonal, 0 will be returned.",
		title07: "Date",
		descr07: "Insert current date during printing",
		title08: "Time",
		descr08: "Insert current time during printing"
	},
	gridLocale: {
		'/': "/", // separator of parts of a date (e.g. '/' in 11/05/1955)
		':': ":", // separator of parts of a time (e.g. ':' in 05:44 PM)
		firstDay: 0, // the first day of the week (0 = Sunday, 1 = Monday, etc)
		days: {
			names:  ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], // full day names
			namesAbbr:  ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], // abbreviated day names
			namesShort:  ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]		// shortest day names
		},
		months: {
			names:  ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""], // full month names (13 months for lunar calendards -- 13th month should be "" if not lunar)
			namesAbbr:  ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""] // abbreviated month names
		},
		// AM and PM designators in one of these forms:
		// The usual view, and the upper and lower case versions
		// [standard,lowercase,uppercase]
		// The culture does not use AM or PM (likely all standard date formats use 24 hour time)
		// null
		AM: ["ΠΜ", "πμ", "ΠΜ"],
		PM: ["ΜΜ", "μμ", "ΜΜ"],
		eras: [
			// eras in reverse chronological order.
			// name: the name of the era in this culture (e.g. A.D., C.E.)
			// start: when the era starts in ticks (gregorian, gmt), null if it is the earliest supported era.
			// offset: offset in years from gregorian calendar
			{"name": "π.Χ.", "start": null, "offset": 0 }
		],
		twoDigitYearMax: 2029,
		patterns: {
			// short date pattern
			d: "d/Μ/yyyy",
			// long date pattern
			D: "dddd, MMMM dd, yyyy",
			// short time pattern
			t: "h:mm tt",
			// long time pattern
			T: "h:mm:ss tt",
			// long date, short time pattern
			f: "dddd, MMMM dd, yyyy h:mm tt",
			// long date, long time pattern
			F: "dddd, MMMM dd, yyyy h:mm:ss tt",
			// month/day pattern
			M: "MMMM dd",
			// month/year pattern
			Y: "yyyy MMMM",
			// S is a sortable format that does not vary by culture
			S: "yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss"
		},
		percentsymbol: "%",
		currencysymbol: "€",
		currencysymbolposition: "after",
		decimalseparator: ',',
		thousandsseparator: '.',
		pagergotopagestring: "Go to page: ",
		pagershowrowsstring: "Show records:",
		pagerrangestring: " from ",
		pagerpreviousbuttonstring: "previous",
		pagernextbuttonstring: "next",
		groupsheaderstring: "Drag a column here for grouping",
		sortascendingstring: "Asc. sorting",
		sortdescendingstring: "Desc. sorting",
		sortremovestring: "Remove sorting",
		groupbystring: "Group by this",
		groupremovestring: "Remove from groups",
		filterclearstring: "Clear",
		filterstring: "Filter",
		filtershowrowstring: "Show records where:",
		filterorconditionstring: "Or",
		filterandconditionstring: "And",
		filterselectallstring: "(Show all)",
		filterchoosestring: "Please select:",
		filterstringcomparisonoperators: ['null', 'no null', 'contains', 'contains(case sensitive)',
		'not contain', 'not contain(case sensitive)', 'starts with', 'starts with(case sensitive)',
		'ends with', 'ends with(case sensitive)', 'equal', 'equal(case sensitive)', 'null', 'not null'],
		filternumericcomparisonoperators: ['equal', 'not equal', 'smaller than', 'smaller or equal to', 'bigger to', 'bigger or equal to', 'null', 'not null'],
		filterdatecomparisonoperators: ['equal', 'not equal', 'smaller than', 'smaller or equal to', 'bigger to', 'bigger or equal to', 'null', 'not null'],
		filterbooleancomparisonoperators: ['equal', 'not equal'],
		validationstring: "Inserted value is not valid"
	},
	
	L_drawLocal: {
		draw: {
			toolbar: {
				// #TODO: this should be reorganized where actions are nested in actions
				// ex: actions.undo  or actions.cancel
				actions: {
					// title: 'Cancel edit',
					text: 'Cancel'
				},
				finish: {
					// title: 'Edit complete',
					text: 'Complete'
				},
				undo: {
					// title: 'Remove last point',
					text: 'Remove last point'
				},
				buttons: {
					polyline: 'Edit polyline',
					polygon: 'Edit polygon',
					rectangle: 'Edit rectangle',
					circle: 'Edit circle',
					marker: 'Edit point',
					circlemarker: 'Edit circle marker'
				}
			},
			handlers: {
				circle: {
					tooltip: {
						start: 'Click and drag to create a circle.'
					},
					radius: 'Radius'
				},
				circlemarker: {
					tooltip: {
						start: 'Click on the map to place a circle marker.'
					}
				},
				marker: {
					tooltip: {
						start: 'Click on the map to place a circle point.'
					}
				},
				polygon: {
					tooltip: {
						start: 'Click to start editing.',
						cont: 'Click to resume editing.',
						end: 'Click on the start point to complete editing.'
					}
				},
				polyline: {
					error: '<strong>Error:</strong> the vertices cant be intersected!',
					tooltip: {
						start: 'Click to start editing.',
						cont: 'Click to resume editing.',
						end: 'Click on the final point to complete editing.'
					}
				},
				rectangle: {
					tooltip: {
						start: 'Click and drag to create a rectangle.'
					}
				},
				simpleshape: {
					tooltip: {
						end: 'Release the mouse to complete editing.'
					}
				}
			}
		},
		edit: {
			toolbar: {
				actions: {
					save: {
						title: 'Save changes',
						text: 'Save'
					},
					cancel: {
						title: 'Cancel edit, changes will be lost',
						text: 'Cancel'
					},
					clearAll:{
						title: 'Clear all editing layers',
						text: 'Clear all'
					}
				},
				buttons: {
					edit: 'Layer edit',
					editDisabled: 'There are no editable layers',
					remove: 'Delete editable layers',
					removeDisabled: 'There are no layers to delete'
				},
				messages: {
					saved: 'Changes saved',
					error: 'An error occured. Try again later!'
				}
			},
			handlers: {
				edit: {
					tooltip: {
						text: 'Drag the points ro the boxes to edit values.',
						subtext: 'Click cancel to undo changes.'
					}
				},
				remove: {
					tooltip: {
						text: 'Click to remove.'
					}
				}
			}
		}
	},
	
	error: {
		loginExpired: "Session has expired, log-in again",
		joinedLayerNotConfigured: "The linked layer was not found in mygis",
	}
	
};