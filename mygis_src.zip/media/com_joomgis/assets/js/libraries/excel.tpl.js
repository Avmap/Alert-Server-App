window.excelExportTpl=''+
'<?xml version="1.0"?>'+
'<?mso-application progid="Excel.Sheet"?>'+
'<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"'+
' xmlns:o="urn:schemas-microsoft-com:office:office"'+
' xmlns:x="urn:schemas-microsoft-com:office:excel"'+
' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"'+
' xmlns:html="http://www.w3.org/TR/REC-html40">'+
'<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">'+
  '<Author></Author>'+
  '<LastAuthor></LastAuthor>'+
  '<LastPrinted></LastPrinted>'+
  '<Created></Created>'+
  '<Version>14.00</Version>'+
'</DocumentProperties>'+
' <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">'+
  '<AllowPNG/>'+
 '</OfficeDocumentSettings>'+
 '<ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">'+
'  <WindowHeight>10545</WindowHeight>'+
  '<WindowWidth>22035</WindowWidth>'+
  '<WindowTopX>360</WindowTopX>'+
  '<WindowTopY>75</WindowTopY>'+
  '<ProtectStructure>False</ProtectStructure>'+
  '<ProtectWindows>False</ProtectWindows>'+
 '</ExcelWorkbook>'+
 '<Styles>'+
'  <Style ss:ID="Default" ss:Name="Normal">'+
   '<Alignment ss:Vertical="Bottom"/>'+
   '<Borders/>'+
   '<Font ss:FontName="Calibri" x:CharSet="161" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>'+
   '<Interior/>'+
   '<NumberFormat/>'+
   '<Protection/>'+
  '</Style>'+
  '<Style ss:ID="s71">'+
'   <Font ss:FontName="Calibri" x:CharSet="161" x:Family="Swiss" ss:Size="11" ss:Color="#000000" ss:Bold="1"/>'+
   '<NumberFormat ss:Format="@"/>'+
  '</Style>'+
  '<Style ss:ID="sCurrency">'+
'   <Font ss:FontName="Calibri" x:CharSet="161" x:Family="Swiss" ss:Size="11" ss:Color="#00B050"/>'+
   '<NumberFormat ss:Format="#,##0.00\ &quot;�&quot;"/>'+
  '</Style>'+
 '</Styles>'+
 '<Worksheet ss:Name="{{HEADER_SHEETNAME}}">'+
'  <Table ss:DefaultRowHeight="15">'+
   '<Row>'+
    '{{COLUMNS}}'+
   '</Row>'+
   '{{ROWS}}'+
  '</Table>'+
  '<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">'+
'   <PageSetup>'+
    '<Layout x:Orientation="Landscape"/>'+
    '<Header x:Margin="0.31496062992125984" x:Data="{{FOOTER_SITE}}"/>'+
    '<Footer x:Margin="0.31496062992125984"'+
     ' x:Data="{{FOOTER_TEXT}}"/>'+
    '<PageMargins x:Bottom="0.74803149606299213" x:Left="0.70866141732283472"'+
'     x:Right="0.70866141732283472" x:Top="0.8417322834645669"/>'+
 '  </PageSetup>'+
   '<Print>'+
'    <ValidPrinterInfo/>'+
    '<PaperSizeIndex>9</PaperSizeIndex>'+
    '<HorizontalResolution>1200</HorizontalResolution>'+
    '<VerticalResolution>1200</VerticalResolution>'+
   '</Print>'+
   '<Selected/>'+
   '<Panes>'+
'    <Pane>'+
     '<Number>3</Number>'+
     '<ActiveRow>1</ActiveRow>'+
     '<ActiveCol>1</ActiveCol>'+
    '</Pane>'+
   '</Panes>'+
   '<ProtectObjects>False</ProtectObjects>'+
   '<ProtectScenarios>False</ProtectScenarios>'+
  '</WorksheetOptions>'+
 '</Worksheet>'+
'</Workbook>';