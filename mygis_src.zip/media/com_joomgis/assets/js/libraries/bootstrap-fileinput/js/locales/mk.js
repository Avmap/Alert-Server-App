/*!
 * FileInput Greek Translations
 *
 * This file must be loaded after 'fileinput.js'. Patterns in braces '{}', or
 * any HTML markup tags in the messages must not be converted or translated.
 *
 * @see http://github.com/kartik-v/bootstrap-fileinput
 *
 * NOTE: this file must be saved in UTF-8 encoding.
 */
(function ($) {
    "use strict";

    $.fn.fileinputLocales['mk'] = {
        fileSingle: 'датотека',
        filePlural: 'датотеки',
        browseLabel: 'Барај &hellip;',
        removeLabel: 'Избриши',
        removeTitle: 'Исчисти датотеки',
        cancelLabel: 'Поништување',
        cancelTitle: 'Откажи ги поставувањата',
        uploadLabel: 'Подигни датотека',
        uploadTitle: 'Поставете ги избраните датотеки',
        msgNo: 'Не',
        msgNoFilesSelected: 'Нема избрани датотеки',
        msgCancelled: 'Откажано',
        msgPlaceholder: 'Select {files}...',
        msgZoomModalHeading: 'Детален преглед',
        msgFileRequired: 'You must select a file to upload.',
        msgSizeTooSmall: '"{name}" (<b>{size} KB</b>) е премногу мал, мора да биде поголем од <b>{minSize} KB</b>.',
        msgSizeTooLarge: 'Датотеката "{name}" (<b>{size} KB</b>) ја надминува максимално дозволената големина на претовар <b>{maxSize} KB</b>.',
        msgFilesTooLess: 'Мора да изберете барем <b>{n}</b> {files} за да започнете со поставувањето.',
        msgFilesTooMany: 'Бројот на датотеки избрани за поставување <b>({n})</b> го надминува максималниот дозволен број <b>{m}</b>.',
        msgFileNotFound: 'Датотеката "{name}" не беше пронајдена!',
        msgFileSecured: 'Безбедносните рестрикции спречија читање на датотеката "{name}".',
        msgFileNotReadable: 'Датотеката "{name}" не може да се чита.',
        msgFilePreviewAborted: 'Прегледот на "{name}" беше откажан.',
        msgFilePreviewError: 'Имаше грешка при читањето на датотеката "{name}".',
        msgInvalidFileName: 'Невалидни знаци во името на датотеката "{name}".',
        msgInvalidFileType: 'Невалиден тип на датотека "{name}". Поддржаните типови на датотеки се : "{types}".',
        msgInvalidFileExtension: 'Неважечка наставката на датотеката "{name}". Поддржани екстензии се : "{extensions}".',
        msgFileTypes: {
            'image': 'image',
            'html': 'HTML',
            'text': 'text',
            'video': 'video',
            'audio': 'audio',
            'flash': 'flash',
            'pdf': 'PDF',
            'object': 'object'
        },
        msgUploadAborted: 'Подигни датотека беше откажана',
        msgUploadThreshold: 'Подигни датотека ...',
        msgUploadBegin: 'Initializing...',
        msgUploadEnd: 'Зачувани',
        msgUploadEmpty: 'No valid data available for upload.',
        msgUploadError: 'Грешка',
        msgValidationError: 'Грешка при валидација',
        msgLoading: 'Додај датотека {index} од {files} &hellip;',
        msgProgress: 'Додај датотека {index} од {files} - {name} - {percent}% завршено.',
        msgSelected: '{n} {files} беа избрани',
        msgFoldersNotAllowed: 'Можете само да влечете датотеки! Тие беа занемарени {n} пликови.',
        msgImageWidthSmall: 'Ширината на сликата "{name}" мора да биде најмалку {size} px.',
        msgImageHeightSmall: 'Висината на сликата "{name}" мора да биде најмалку {size} px.',
        msgImageWidthLarge: 'Ширината на сликата "{name}" не може да надмине {size} px.',
        msgImageHeightLarge: 'Висината на сликата "{name}" не може да надмине {size} px.',
        msgImageResizeError: 'Не може да се најдат димензиите на сликата за промена на големината.',
        msgImageResizeException: 'Грешка при промена на големината на сликата. <pre>{errors}</pre>',
        msgAjaxError: 'Something went wrong with the {operation} operation. Please try again later!',
        msgAjaxProgressError: '{operation} failed',
        ajaxOperations: {
            deleteThumb: 'file delete',
            uploadThumb: 'file upload',
            uploadBatch: 'batch file upload',
            uploadExtra: 'form data upload'
        },
        dropZoneTitle: 'Повлечете ги тука датотеките &hellip;',
        dropZoneClickTitle: '<br>(или притиснете за да изберете {files})',
        fileActionSettings: {
            removeTitle: 'Отстранете ја датотеката',
            uploadTitle: 'Поставете ја датотеката',
            uploadRetryTitle: 'Retry upload',
            downloadTitle: 'Download file',
            zoomTitle: 'Видете детали',
            dragTitle: 'Премести / задача',
            indicatorNewTitle: 'Сеуште не е поставено',
            indicatorSuccessTitle: 'Поставено',
            indicatorErrorTitle: 'Испрати грешка',
            indicatorLoadingTitle: 'Подигни датотека ...'
        },
        previewZoomButtonTitles: {
            prev: 'Претходна датотека',
            next: 'Следна датотека',
            toggleheader: 'Прикажи / скриј на наслов',
            fullscreen: 'Префрли го целиот екран',
            borderless: 'Со или без рамка',
            close: 'Затвори ја проекцијата'
        }
    };
})(window.jQuery);
