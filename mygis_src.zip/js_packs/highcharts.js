/* start of Highcharts */
import highcharts from 'libraries/highcharts/highcharts.js';
import h_3d from 'libraries/highcharts/highcharts-3d.js';
import h_more from 'libraries/highcharts/highcharts-more.js';
import h_drill from 'libraries/highcharts/modules/drilldown.js';
import h_rgb from 'libraries/highcharts/lib/rgbcolor.js';

h_3d(highcharts);
h_more(highcharts);
h_drill(highcharts);
//h_rgb(highcharts);
/* end of Highcharts */
global.Highcharts = highcharts;