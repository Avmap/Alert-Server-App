var pdfMake = require('libraries/pdfmake/pdfmake.js');
var pdfFonts = require('libraries/pdfmake/vfs_fonts.js');
pdfMake.vfs = pdfFonts.pdfMake.vfs; 
global.pdfmake = pdfMake;