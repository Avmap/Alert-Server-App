import 'templates/joomgis/build/reset.css';
import 'templates/joomgis/build/desktop.css';
import 'templates/joomgis/build/tablet.css';
import 'templates/joomgis/build/mobile.css';
