import 'libraries/bootstrap-fileinput/css/fileinput.min.css';
import 'libraries/bootstrap-toggle/css/bootstrap-toggle.min.css';

import 'libraries/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css';
import 'libraries/bootstrap-combobox/bootstrap-combobox.css';
import 'libraries/jquery-confirm/jquery-confirm.min.css';


