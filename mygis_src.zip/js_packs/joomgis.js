require('libraries/layerControl.js');
require('libraries/excel.tpl.js');

import joomgis_strings_gr from  'media/com_joomgis/assets/js/language/strings_gr.js';
import joomgis_strings_en from  'media/com_joomgis/assets/js/language/strings_en.js';
import joomgis_strings_mk from  'media/com_joomgis/assets/js/language/strings_mk.js';
import joomgis_Styling from  'models/styling.js';
import joomgis_Utils from  'models/utils.js';
import joomgis_Common from  'models/common.js';
import joomgis_Searching from  'models/searching.js';
import joomgis_Layers from  'models/layers.js';
import joomgis_Info from  'models/info.js';
import joomgis_PrintTemplates from  'models/printTemplates.js';
import joomgis_Graphs from  'models/graphs.js';
import joomgis_Table from  'models/table.js';
import joomgis_Admin from  'models/admin.js';

global.joomgis_strings_pool={
	'en':joomgis_strings_en,
	'gr':joomgis_strings_gr,
	'mk':joomgis_strings_mk
};
global.joomgis_strings=joomgis_strings_gr;
global.joomgis_styling=joomgis_Styling;
global.joomgis_utils=joomgis_Utils;
global.joomgis_common=joomgis_Common;
global.joomgis_searching=joomgis_Searching;
global.joomgis_layers=joomgis_Layers;
global.joomgis_info=joomgis_Info;
global.joomgis_printTemplates=joomgis_PrintTemplates;
global.joomgis_graphs=joomgis_Graphs;
global.joomgis_table=joomgis_Table;
global.joomgis_admin=joomgis_Admin;
