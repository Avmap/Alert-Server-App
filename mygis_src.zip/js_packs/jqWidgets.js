import 'libraries/jqwidgets/styles/jqx.base.css';
import 'libraries/jqwidgets/styles/jqx.fresh.css'

/* start of JQWidgets */
import jqxBaseFramework from 'libraries/jqwidgets/jqxcore.js';
require('libraries/jqwidgets/jqxbuttons.js');
require('libraries/jqwidgets/jqxcheckbox.js');
require('libraries/jqwidgets/jqxcombobox.js');
require('libraries/jqwidgets/jqxdata.js');
require('libraries/jqwidgets/jqxdropdownbutton.js');
require('libraries/jqwidgets/jqxgrid.js');
require('libraries/jqwidgets/jqxinput.js');
require('libraries/jqwidgets/jqxgrid.edit.js');
require('libraries/jqwidgets/jqxgrid.selection.js');
require('libraries/jqwidgets/jqxgrid.filter.js');
require('libraries/jqwidgets/jqxgrid.pager.js');
require('libraries/jqwidgets/jqxgrid.sort.js');
require('libraries/jqwidgets/jqxgrid.columnsresize.js');
require('libraries/jqwidgets/jqxloader.js');
require('libraries/jqwidgets/jqxnumberinput.js');
require('libraries/jqwidgets/jqxscrollbar.js');
require('libraries/jqwidgets/jqxlistbox.js');
require('libraries/jqwidgets/jqxdropdownlist.js');
require('libraries/jqwidgets/jqxmenu.js');
/* end of JQWidgets */