// Import TinyMCE
import tinymce from 'libraries/tinymce/tinymce.min.js';

// A theme is also required
import 'libraries/tinymce/themes/modern/theme.min.js';

// Any plugins you want to use has to be imported
import 'libraries/tinymce/plugins/anchor/plugin.min.js';
import 'libraries/tinymce/plugins/autoresize/plugin.min.js';
import 'libraries/tinymce/plugins/code/plugin.min.js';
import 'libraries/tinymce/plugins/contextmenu/plugin.min.js';
import 'libraries/tinymce/plugins/hr/plugin.min.js';
import 'libraries/tinymce/plugins/link/plugin.min.js';
import 'libraries/tinymce/plugins/lists/plugin.min.js';
import 'libraries/tinymce/plugins/nonbreaking/plugin.min.js';
import 'libraries/tinymce/plugins/paste/plugin.min.js';
import 'libraries/tinymce/plugins/tabfocus/plugin.min.js';
import 'libraries/tinymce/plugins/table/plugin.min.js';
import 'libraries/tinymce/plugins/template/plugin.min.js';
import 'libraries/tinymce/plugins/textcolor/plugin.min.js';
import 'libraries/tinymce/plugins/textpattern/plugin.min.js';
import 'libraries/tinymce/plugins/visualblocks/plugin.min.js';
import 'libraries/tinymce/plugins/visualchars/plugin.min.js';
import 'libraries/tinymce/plugins/wordcount/plugin.min.js';

global.tinymce = tinymce;