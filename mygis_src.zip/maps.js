//require("babel-register");
require('libraries/url-search-params.js');
require('libraries/jsrender.min.js');
require('libraries/jquery.observable.js');
require('libraries/jquery.views.js');
require('./templates/joomgis/build/app.js');
//global.joomgis_strings=joomgis_strings;
import joomgis_strings_gr from  'media/com_joomgis/assets/js/language/strings_gr.js';
import joomgis_strings_en from  'media/com_joomgis/assets/js/language/strings_en.js';
import joomgis_strings_mk from  'media/com_joomgis/assets/js/language/strings_mk.js';

global.joomgis_strings_pool={
	'en':joomgis_strings_en,
	'gr':joomgis_strings_gr,
	//'mk':joomgis_strings_mk
};
global.joomgis_strings={};
function getPath(name) {
		var baseFolder='/media/com_joomgis/assets/js/controls/tmpl/';
		var subFolder='';
		switch(name){
			case 'joinedResults':
			case 'userJoinedResults':
			case 'nodes':
			case 'certificates':
			case 'certificatesUserInput':
			case 'certificateCreation':
			case 'certificateManagement':
			case 'certificatePrintManagement':
			case 'certificatePrintManagementPopup':
				subFolder='infoSub/';
				break;
		}
		return baseFolder+subFolder+name+'.tpl.html';
	};
function renderExtTemplate(item,callback) {
	var file = getPath( item.name );
	jQuery.when(jQuery.get(file))
	 .done(function(tmplData) {
		 window.jsrender=jQuery;
		 window.jsrender.templates(
			{ tmpl: tmplData});
		 jQuery(item.selector).html(window.jsrender.render.tmpl(item.data,{
				str: function(key){
					return joomgis_strings[key];
				}
			}));
		 if (callback){
			callback();
		}
	 });    
};
function showLoginError(msg){
	jQuery(".loginErr").remove();
	jQuery("#login-form .userdata").prepend("<div class='loginErr error'>"+msg+"</div>");
}
function waitLogin(){
	clearWaitLogin();
	var btn=jQuery("#login-form button");
	btn.prepend("<i class='fa fa-spinner fa-spin'></i>");
	btn.addClass("disabled");
}
function clearWaitLogin(){
	var btn=jQuery("#login-form button");
	btn.find("i").remove();
	btn.removeClass("disabled");
}
global.jQuery = require('jquery');
global.jQuery(document).ready(function($){
	var wrapper = jQuery('<div class="t3-module module flags" />');
	jQuery.each(joomgis_strings_pool,function(lang,pool){
		
		var div = jQuery('<div class="flag-cont '+pool['langSuffix'].replace("_","")+'">'+
							'<a href="index'+pool['langSuffix']+'.html">'+pool['langTitle']+'</a>'+
						'</div>');
		wrapper.append(div);
		
	});
	wrapper.prependTo($("#t3-header"));
	var url = new URL(window.location);
	var paramLang = url.pathname.replace("/index","").replace(".html","");
	var langSuffix=((paramLang&&paramLang.length>1)?paramLang.replace("_",""):"gr");
	joomgis_strings = joomgis_strings_pool[langSuffix];
	var loadMaps = function(){
		$.ajax({
			url: '/app?view=getMaps',
			error: function (xhr, ajaxOptions, thrownError) {
				alert("Server down - Check with Hosting Support. Error message: "+thrownError);
			},
			success: function(data){
				renderExtTemplate({
					name: "loadMaps",
					data: data,
					selector: "#mapContainerWrapper"
				},function(){
					if (window.location.hash){
						var anch=jQuery("[id='"+decodeURI(window.location.hash.replace("#",""))+"']");
						var scrollTop=anch.offset().top;
						jQuery("html,body").animate({scrollTop:scrollTop},1000);
					}
				});
				
			}
		});
	};
	function loginSubm(event){
		event.preventDefault();
		if (!jQuery("#modlgn-username").val() && !jQuery("#modlgn-passwd").val() && !(jQuery("body").hasClass("loggedIn"))){
			showLoginError(joomgis_strings["loginNotFilledIn"]);
		}else{
			waitLogin();
			var data = $('#login-form').serialize();
			data = data.replace("&task=user.login","");
			data = data.replace("&task=user.logout","");
			data = data.replace("&option=com_users","");
			data = data.replace("option=com_users","");
			$.ajax({
				url: '/app?view=login&logout='+window.isLoggedIn,
				method: 'POST',
				data: data,
				success: function(resp,textStatus,xhr){
					clearWaitLogin();
					if (!resp.login){
						showLoginError(joomgis_strings["wrongLogin"]);
					}else{
						
						if (resp.msg){
							if (resp.msg=="Invalid token"){//session expired.
								alert(joomgis_strings["invalidToken"]);
								window.location.reload();
							}
							showLoginError(resp.msg);
						}else{
							window.isLoggedIn=resp.isLoggedIn;
							if (window.isLoggedIn){
								$("body").addClass("loggedIn");
							}else{
								$("body").removeClass("loggedIn");
							}
							jQuery("#loginModal").modal('hide');
							loadMaps();
							$("#loginModal .modal-content").html(resp.login);
							jQuery("#login-form").off('submit').on('submit',loginSubm);
						}
					}
					
				}
			});
		}
		
	}
	$.ajax({
		url: '/'+joomgis_strings.joomlaPrefix+'/app?view=getGlobalConfig',
		error: function (xhr, ajaxOptions, thrownError) {
			alert("Server down - Check with Hosting Support. Error message: "+thrownError);
		},success: function(data){
			window.isLoggedIn=data.isLoggedIn||(!navigator.onLine);	//this will show all public maps if offline
			if (window.isLoggedIn){
				$("body").addClass("loggedIn");
			}else{
				$("body").removeClass("loggedIn");
			}
			$("#t3-header .actualName").html(data.appName);
			$("#loginModal .modal-content").html(data.login);
			
			$(".footer").html(data.footer);
			jQuery('.e-overview-item').hover(function() {
				//jQuery('.e-overview-item').removeClass("m-active");
				jQuery(this).toggleClass('m-hover');
			});
			jQuery('.e-overview-item').click(function(event) {
				//debugger;
				clearTimeout(window.demoTimer);
				window.demoFlag=false;
				//jQuery('.e-overview-item').removeClass("m-active");
				jQuery.each(jQuery('.e-overview-item'),function(i,item){
					if (jQuery(item)[0]==event.currentTarget){
					
					}else{
						jQuery(item).removeClass("m-active");
					}
				});
				
				jQuery(this).toggleClass('m-active');
			});
			jQuery('#login-form a.ajaxLoad').on('click',function() {
				var url = this.href;
				// show a spinner or something via css
				var dialog = $('<div style="display:none" class="loading additionalModal"><iframe style=\"width:600px;height:300px;\"></iframe></div>').appendTo('body');
				var iframe=dialog.find("iframe");
				// open the dialog
				dialog.modal({
					// add a close listener to prevent adding multiple divs to the document
					close: function(event, ui) {
						// remove div with all data and events
						dialog.remove();
					},
					modal: true,
				});
				// load remote content
				iframe.attr("src",url);
				dialog.removeClass('loading');
				jQuery('body').on('click',function(){
					dialog.remove();
				});
				//prevent the browser to follow the link
				return false;
			});
			jQuery("#login-form").off('submit').on('submit',loginSubm);
			if (data.plugins){
				jQuery.each(data.plugins,function(trigger,plugin){
					if (trigger.indexOf("onLoad")===0){
						var payload = $(plugin.payload);
						var scripts = payload.find("script");
						scripts.remove();
						$("body").append(payload[0]);
						jQuery.each(scripts,function(i,scr){
							eval(scr.innerText);
						});
						payload.remove();
					}
				});
			}
			
		}
	});
	
	loadMaps();
	jQuery("#nav-btn").click(function() {
		  jQuery(".navbar-collapse").collapse("toggle");
		  return false;
		});
	jQuery("#loginModal").on('shown.bs.modal',function(){
		jQuery("#modlgn-username").focus();
	});
	jQuery(".login-btn").click(function() {
		
		//If user is logged in.
		if(jQuery("body").hasClass("loggedIn"))
		{
			jQuery("#login-form").submit(); //Log out at once.
		}
		else
		{
			jQuery("#loginModal").modal("show");
			jQuery(".navbar-collapse.in").collapse("hide");
			
		}
	  
	  return false;
	});
	
	jQuery(".about-btn").click(function() {
	  jQuery("#aboutModal").modal("show");
	  jQuery(".navbar-collapse.in").collapse("hide");
	  return false;
	});
	 
	
});