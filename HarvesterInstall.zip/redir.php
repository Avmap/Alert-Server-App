<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

/* Disable until a proper source & referrer check is in place
$url = (string) $_GET['url'];
$url = urldecode($url);
header('Location: '.$url);
*/
